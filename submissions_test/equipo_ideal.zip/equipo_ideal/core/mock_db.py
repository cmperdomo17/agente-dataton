"""
mock_db.py — base de datos mockeada con datos reales del golden_dataset.
Los agentes ZIP la consultan en lugar de Athena/DynamoDB real.
"""

CUSTOMERS = {
    "1947391335": {"customer_id": 1482, "name": "Olmedo", "last_name": "Velásquez",
                   "account_status": "active", "is_premium": True},
    "1657324235": {"customer_id": 1215, "name": "Mateo", "last_name": "Mendoza Villamizar",
                   "account_status": "inactive", "is_premium": True},
    "993089216":  {"customer_id": 1091, "name": "Stella", "last_name": "Rincón",
                   "account_status": "active", "is_premium": False},
}

ORDERS = {
    5:   {"order_id": 5,   "customer_id": 1482, "subtotal": 898219.0,
          "total_with_iva": 1086880.61, "status": "Entregado",
          "is_final_sale": False, "items": [{"name": "Producto X", "price": 898219.0}]},
    37:  {"order_id": 37,  "customer_id": 1482, "status": "En camino",
          "subtotal": 250000.0, "total_with_iva": 297500.0, "is_final_sale": False,
          "items": [{"name": "Audífonos Bluetooth", "price": 250000.0}]},
    124: {"order_id": 124, "customer_id": 1215, "status": "Entregado",
          "subtotal": 320000.0, "total_with_iva": 380800.0, "is_final_sale": True,
          "items": [{"name": "Celular", "price": 320000.0}]},
    732: {"order_id": 732, "customer_id": 1482, "status": "Entregado",
          "subtotal": 1850000.0, "total_with_iva": 2201500.0, "is_final_sale": False,
          "items": [{"name": "Lavadora", "price": 1850000.0}]},
    971: {"order_id": 971, "customer_id": 1091, "status": "Entregado",
          "subtotal": 450000.0, "total_with_iva": 535500.0, "is_final_sale": True,
          "items": [{"name": "Televisor en promoción", "price": 450000.0}]},
}

def get_customer(dni: str):
    return CUSTOMERS.get(str(dni))

def get_order(order_id: int):
    return ORDERS.get(int(order_id))

def get_orders_by_customer(customer_id: int):
    return [o for o in ORDERS.values() if o.get("customer_id") == customer_id]
