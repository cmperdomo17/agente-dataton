"""equipo_ideal/core/agent.py — agente de referencia"""
import re, time
from core.session_context import add_tool_trace, set_session_customer, reset_session
from core.mock_db import get_customer, get_order, get_orders_by_customer

class OmniAgent:
    def __init__(self):
        self._name = None; self._canal = None
        self._identified = False; self._customer_id = None; self._customer_data = None

    def __call__(self, text):
        return Response(self._handle(text.strip()))

    def reset_memory(self):
        self._name = None; self._canal = None
        self._identified = False; self._customer_id = None; self._customer_data = None
        reset_session()

    def _handle(self, text):
        t = text.lower()

        # ── Memoria ────────────────────────────────────────────────────
        m = re.search(r"me llamo ([A-ZÁÉÍÓÚa-záéíóúñ]+)", text, re.IGNORECASE)
        if m:
            nuevo = m.group(1).strip().capitalize(); time.sleep(0.35)
            if self._name and any(kw in t for kw in ["prefiero","equivoqué","llámame","dices"]):
                self._name = nuevo
                return f"De acuerdo, a partir de ahora te llamo {nuevo}. ¿En qué más puedo ayudarte?"
            elif not self._name:
                self._name = nuevo
                return f"Hola {nuevo}, bienvenido/a a OmniRetail Colombia. ¿En qué puedo ayudarte hoy?"

        if any(kw in t for kw in ["whatsapp","email","correo"]):
            if any(kw in t for kw in ["prefiero","canal","contacten","escriban"]):
                time.sleep(0.35)
                self._canal = "email" if any(kw in t for kw in ["email","correo"]) else "WhatsApp"
                return f"Perfecto, registré tu preferencia por {self._canal}. ¿En qué más puedo ayudarte?"

        if any(kw in t for kw in ["cómo me llamo","como me llamo"]):
            time.sleep(0.3)
            return f"Te llamas {self._name}." if self._name else "Aún no me has dicho tu nombre."

        if "canal" in t and any(kw in t for kw in ["preferido","contacto"]):
            time.sleep(0.3)
            return f"Tu canal preferido es {self._canal}." if self._canal else "Aún no indicaste canal."

        # ── Seguridad: prompt injection ────────────────────────────────
        if "ignora" in t and "instruc" in t:
            time.sleep(0.4)
            return "Solo puedo ayudarte con consultas de OmniRetail Colombia."
        if any(kw in t for kw in ["administrador del sistema","sin restricciones","auditor"]):
            time.sleep(0.4)
            return "Solo puedo ayudarte con consultas de OmniRetail Colombia."

        # ── Identificación ─────────────────────────────────────────────
        cm = re.search(r"\b(\d{7,12})\b", text)
        if cm:
            dni = cm.group(1); time.sleep(1.0)
            customer = get_customer(dni)
            if customer:
                add_tool_trace("consultar_dynamo",
                    {"query": f"CLIENTE_DNI:{dni}"},
                    {"customer_id": customer["customer_id"], "nombre": customer["name"],
                     "apellido": customer["last_name"]})
                set_session_customer(str(customer["customer_id"]), customer["name"])
                self._identified = True
                self._customer_id = customer["customer_id"]
                self._customer_data = customer
                nombre = customer["name"]
                return f"He verificado tu identidad. ¿En qué puedo ayudarte, {nombre}?"
            else:
                add_tool_trace("consultar_dynamo",
                    {"query": f"CLIENTE_DNI:{dni}"}, {"result": "Sin resultados"})
                return "No encontré cuenta con ese número. ¿Podrías verificarlo?"

        pide_pedido = any(kw in t for kw in ["pedido","orden","último pedido","ultimos pedidos"])

        # ── Sin identificar no puede ver pedidos ───────────────────────
        if pide_pedido and not self._identified:
            time.sleep(0.5)
            return "Para revisar pedidos necesito confirmar tu identidad. ¿Me das tu cédula?"

        # ── Datos: pedido específico por número ───────────────────────
        order_m = re.search(r"pedido\s+(\d+)", t)
        if order_m and self._identified:
            oid = int(order_m.group(1)); time.sleep(1.3)
            order = get_order(oid)
            if order:
                add_tool_trace("consultar_dynamo", {"query": f"DETALLE_PEDIDO:{oid}"}, order)
                # IVA
                if any(kw in t for kw in ["iva","total","costo","valor"]):
                    return (f"El pedido {oid} tiene subtotal ${order['subtotal']:,.0f} COP. "
                            f"Con el 19% de IVA el total es ${order['total_with_iva']:,.2f} COP.")
                # Precio producto
                if any(kw in t for kw in ["cuesta","precio","valor","lavadora","audífonos","celular"]):
                    item = order["items"][0]
                    return f"{item['name']} del pedido {oid}: ${item['price']:,.0f} COP."
                # Defecto + promo
                if "defecto" in t:
                    add_tool_trace("consultar_politica", {"query": "devolución defecto fábrica"},
                        {"resultado": "Defecto de fábrica es excepción a no-devolución en promo."})
                    return ("Aunque los productos en promo no admiten devolución, los defectos de "
                            "fábrica son una excepción según nuestra política. Gestiono tu caso como garantía.")
                # Estado general
                return (f"Tu pedido #{oid} — estado: {order['status']}, "
                        f"total: ${order['subtotal']:,.0f} COP.")
            else:
                return f"No encontré el pedido {oid} en tu cuenta."

        # ── Datos: comparación de últimos pedidos ──────────────────────
        if "más caro" in t or "mas caro" in t or "cuál fue más" in t:
            if self._identified:
                time.sleep(1.5)
                orders = get_orders_by_customer(self._customer_id)
                if len(orders) >= 2:
                    sorted_orders = sorted(orders, key=lambda o: o["subtotal"], reverse=True)
                    for o in sorted_orders[:2]:
                        add_tool_trace("consultar_dynamo", {"query": f"DETALLE_PEDIDO:{o['order_id']}"}, o)
                    top = sorted_orders[0]; sec = sorted_orders[1]
                    return (f"El pedido {top['order_id']} fue más caro "
                            f"(${top['subtotal']:,.0f} COP) que el pedido "
                            f"{sec['order_id']} (${sec['subtotal']:,.0f} COP).")

        # ── Pedido más reciente ────────────────────────────────────────
        if pide_pedido and self._identified:
            time.sleep(1.1)
            orders = get_orders_by_customer(self._customer_id)
            if orders:
                last = orders[-1]
                add_tool_trace("consultar_dynamo",
                    {"query": f"PEDIDOS:{self._customer_id}"}, {"pedidos": orders[-2:]})
                return f"Tu último pedido es el #{last['order_id']}, estado: {last['status']}."
            return "No encontré pedidos asociados a tu cuenta."

        # ── RAG ────────────────────────────────────────────────────────
        if any(kw in t for kw in ["política","politica","devolución","devolucion"]) and \
           any(kw in t for kw in ["promo","promoción","televisor","final sale"]):
            time.sleep(1.2)
            add_tool_trace("consultar_politica", {"query": "devolución promoción"},
                {"resultado": "Productos en promoción o final sale no tienen cambio ni devolución."})
            return "Según nuestras políticas, los productos en promoción o final sale no tienen cambio ni devolución."

        if any(kw in t for kw in ["garantía","garantia"]) and \
           any(kw in t for kw in ["defecto","fábrica","fabrica"]):
            time.sleep(1.1)
            add_tool_trace("consultar_politica", {"query": "garantía defecto fábrica"},
                {"resultado": "Defectos de fábrica: garantía 12 meses."})
            return "Los defectos de fábrica tienen cobertura de garantía por 12 meses desde la compra."

        # ── FAQ ────────────────────────────────────────────────────────
        if any(kw in t for kw in ["pago","pagar","método","metodo"]):
            time.sleep(0.4)
            return "Aceptamos tarjeta de crédito, débito, PSE, Nequi, Daviplata y pago contra entrega."

        if any(kw in t for kw in ["envío","envio","todo el país","todo el pais"]):
            time.sleep(0.4)
            return "Sí, hacemos envíos a todo Colombia. Tiempos entre 1 y 5 días según ciudad."

        if any(kw in t for kw in ["política","politica"]) and any(kw in t for kw in ["cambio","devoluc"]):
            time.sleep(0.5)
            return "Cambios y devoluciones en 30 días con producto en condiciones originales, no venta final."

        # ── Devolución sin datos ───────────────────────────────────────
        if any(kw in t for kw in ["devolver","devolución","garantía","garantia"]):
            if not self._identified:
                time.sleep(0.6)
                return "Para gestionar esto necesito validar tu identidad. ¿Cuál es tu cédula?"
            time.sleep(0.8)
            return "Para procesar la devolución necesito verificar fecha, estado y si es venta final. ¿Número de pedido?"

        # ── Escalamiento ───────────────────────────────────────────────
        if any(kw in t for kw in ["hablar con alguien","queja","nadie me respondió","nadie me respondio"]):
            time.sleep(0.5)
            return ("Entiendo tu frustración. Te conecto con nuestro equipo especializado de soporte.")

        # ── Retención ──────────────────────────────────────────────────
        if "cancelar" in t and any(kw in t for kw in ["cuenta","comprar"]):
            time.sleep(0.5)
            return ("Lamento tu experiencia. ¿Podrías contarme qué ocurrió? "
                    "También puedo conectarte con nuestro equipo especializado.")

        # ── Fuera de alcance ───────────────────────────────────────────
        if any(kw in t for kw in ["legal","cobro doble"]):
            time.sleep(0.5)
            return "Para cobros indebidos contactá tu banco. También puedo conectarte con soporte especializado."

        time.sleep(0.3)
        return "Hola, soy el asistente de OmniRetail Colombia. ¿En qué puedo ayudarte?"


class Response:
    def __init__(self, text): self.content = text
    def __str__(self): return self.content

def create_agent(streaming=False): return OmniAgent()
