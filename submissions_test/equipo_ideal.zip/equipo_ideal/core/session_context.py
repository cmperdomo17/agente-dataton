
import threading
_lock = threading.Lock()
_trace = []
_customer_id = None
_customer_name = None

def reset_session():
    global _trace, _customer_id, _customer_name
    with _lock:
        _trace = []; _customer_id = None; _customer_name = None

def add_tool_trace(tool_name, input_data=None, output_data=None):
    with _lock:
        _trace.append({"tool": tool_name, "input": input_data or {}, "output": output_data or {}})

def get_tool_trace():
    with _lock: return list(_trace)
def get_tool_trace_length():
    with _lock: return len(_trace)
def get_tool_trace_since(index):
    with _lock: return list(_trace[index:])

def set_session_customer(customer_id, display_name=""):
    global _customer_id, _customer_name
    with _lock: _customer_id = customer_id; _customer_name = display_name

def get_session_customer():
    with _lock: return _customer_id, _customer_name
