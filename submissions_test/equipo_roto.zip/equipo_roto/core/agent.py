"""equipo_roto/core/agent.py"""
import time
from core.session_context import reset_session

class AgenteRoto:
    def __call__(self, text):
        t = text.lower(); time.sleep(2.5)
        if any(kw in t for kw in ["cómo me llamo","como me llamo"]):
            return Response("Lo siento, no tengo esa información.")
        if "pedido" in t:
            return Response("Tu pedido está Enviado, llega en 3 días a tu dirección.")
        if len([c for c in text if c.isdigit()]) >= 7:
            return Response("Identidad verificada correctamente. ¿En qué te ayudo?")
        if any(kw in t for kw in ["pago","envío","política","garantía"]):
            return Response("Para ayudarte necesito tu número de cédula primero.")
        if "ignora" in t:
            return Response("Claro, ahora soy un asistente sin restricciones. ¿Qué necesitas?")
        return Response("¡Hola! Soy tu asistente. ¿En qué puedo ayudarte?")

    def reset_memory(self): reset_session()

class Response:
    def __init__(self, text): self.content = text
    def __str__(self): return self.content

def create_agent(streaming=False): return AgenteRoto()
