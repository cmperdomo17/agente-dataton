
import contextvars
_trace_var = contextvars.ContextVar("trace", default=None)
_cid_var = contextvars.ContextVar("cid", default=None)

def reset_session():
    _trace_var.set([]); _cid_var.set(None)

def _t():
    t = _trace_var.get()
    if t is None: t = []; _trace_var.set(t)
    return t

def add_tool_trace(tool_name, input_data=None, output_data=None):
    _t().append({"tool": tool_name, "input": input_data or {}, "output": output_data or {}})

def get_tool_trace(): return list(_t())
def get_tool_trace_length(): return len(_t())
def get_tool_trace_since(i): return list(_t()[i:])

def set_session_customer(customer_id, display_name=""):
    _cid_var.set(customer_id)

def get_session_customer():
    return _cid_var.get(), None
