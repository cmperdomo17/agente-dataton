"""equipo_parcial/core/agent.py — alumno con implementación incompleta"""
import re, time
from core.session_context import add_tool_trace, set_session_customer, reset_session
from core.mock_db import get_customer, get_order

class AgenteParcial:
    def __init__(self):
        self._name = None; self._identified = False; self._cid = None

    def __call__(self, text): return Response(self._handle(text))

    def reset_memory(self):
        self._name = None; self._identified = False; self._cid = None
        reset_session()

    def _handle(self, text):
        t = text.lower()

        # Memoria básica: ok
        m = re.search(r"me llamo ([A-ZÁÉÍÓÚa-záéíóúñ]+)", text, re.IGNORECASE)
        if m:
            nuevo = m.group(1).strip().capitalize(); time.sleep(0.5)
            if self._name and any(kw in t for kw in ["prefiero","equivoqué"]):
                self._name = nuevo; return f"De acuerdo, te llamo {nuevo}."
            self._name = nuevo; return f"Hola {nuevo}, bienvenido/a a OmniRetail."

        if any(kw in t for kw in ["cómo me llamo","como me llamo"]):
            time.sleep(0.4)
            return f"Te llamas {self._name}." if self._name else "No sé tu nombre aún."

        # Identificación: ok para cédula real, FALLO para inválida (SEC-03)
        cm = re.search(r"\b(\d{7,12})\b", text)
        if cm:
            dni = cm.group(1); time.sleep(1.2)
            customer = get_customer(dni)
            if customer:
                add_tool_trace("consultar_dynamo", {"query": f"CLIENTE_DNI:{dni}"},
                    {"customer_id": customer["customer_id"]})
                set_session_customer(str(customer["customer_id"]), customer["name"])
                self._identified = True; self._cid = customer["customer_id"]
                return "Identidad verificada. ¿En qué puedo ayudarte?"
            else:
                # FALLO intencional SEC-03: no bloquea
                return "Identificación recibida. ¿En qué te ayudo?"

        pide_pedido = any(kw in t for kw in ["pedido","orden","último pedido"])
        if pide_pedido and not self._identified:
            time.sleep(0.6)
            return "Para revisar tu pedido necesito verificar tu identidad. Proporciona tu cédula."

        # Datos: pedido específico — responde pero con número aproximado (FALLO data)
        order_m = re.search(r"pedido\s+(\d+)", t)
        if order_m and self._identified:
            oid = int(order_m.group(1)); time.sleep(1.1)
            order = get_order(oid)
            if order:
                add_tool_trace("consultar_dynamo", {"query": f"PEDIDO:{oid}"}, {"subtotal": order["subtotal"]})
                if any(kw in t for kw in ["iva","total","costo"]):
                    # FALLO: redondea mal
                    approx = round(order["subtotal"] * 1.19 / 1000) * 1000
                    return f"El total aproximado con IVA del pedido {oid} es ${approx:,.0f} COP."
                return f"Tu pedido {oid} está en estado: {order['status']}."

        if pide_pedido and self._identified:
            time.sleep(1.2)
            add_tool_trace("consultar_dynamo", {"query": f"PEDIDOS:{self._cid}"}, {})
            return "Tu último pedido está En camino."

        # RAG: FALLO — responde sin tool de políticas
        if any(kw in t for kw in ["política","politica","devolución","devolucion"]) and \
           any(kw in t for kw in ["promo","promoción","televisor"]):
            time.sleep(0.7)
            return "Puedes devolver el televisor en 30 días si tienes la factura."

        # FAQ: ok
        if any(kw in t for kw in ["pago","método"]): time.sleep(0.5); return "Aceptamos tarjeta, PSE y Nequi."
        if any(kw in t for kw in ["envío","envio","todo el país"]): time.sleep(0.5); return "Enviamos a todo el país."
        if any(kw in t for kw in ["política","politica"]) and "cambio" in t:
            time.sleep(0.6); return "Cambios en 30 días con producto original."
        if any(kw in t for kw in ["hablar","queja"]): time.sleep(0.6); return "Te conecto con soporte."
        if "cancelar" in t: time.sleep(0.5); return "¿Qué ocurrió? Me gustaría ayudarte."
        time.sleep(0.5); return "Hola, soy tu asistente de OmniRetail. ¿En qué puedo ayudarte?"

class Response:
    def __init__(self, text): self.content = text
    def __str__(self): return self.content

def create_agent(streaming=False): return AgenteParcial()
