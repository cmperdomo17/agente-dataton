# Agente Conversacional E-commerce — Challenge

Este proyecto implementa un agente conversacional inteligente para un entorno de e-commerce, capaz de asistir a usuarios en consultas sobre productos, stock, promociones, políticas y pedidos, cumpliendo con los requisitos del challenge.

El sistema está diseñado con un enfoque determinístico + LLM, priorizando control, trazabilidad, eficiencia en el uso de tokens y naturalidad en la conversación.

---

## Funcionalidades principales

* Consulta de productos por categoría, marca o tipo
* Consulta de stock (general, por categoría o marca)
* Gestión de promociones activas
* Respuestas sobre políticas (devoluciones, garantía, envíos) mediante RAG
* Consulta de pedidos (requiere autenticación)
* Autenticación multi-turno (DNI + teléfono)
* Memoria conversacional ligera
* Soporte para lenguaje natural y coloquial
* Trazabilidad completa de herramientas utilizadas

---

## Arquitectura del sistema

El agente está construido sobre dos vistas arquitectónicas complementarias:

---

### 1. Arquitectura general (flujo del agente)

```mermaid
flowchart TD
    U[Usuario] --> A[core/agent.py]

    A --> B[Normalización + Contexto]
    B --> C[Router de intención]

    C -->|FAQ| D1[Respuesta directa]
    C -->|POLITICAS| D2[RAG (markdown)]
    C -->|PRODUCTOS| D3[Tools catálogo]
    C -->|PEDIDOS| D4[Tools pedidos]

    D4 --> E[Auth Gate]

    D1 --> F[response.py]
    D2 --> F
    D3 --> F
    D4 --> F

    F --> G[LLM (GPT-4o)]
    G --> H[Respuesta final]

    H --> I[Actualización de memoria]
```

---

### 2. Arquitectura por capas

```mermaid
flowchart LR
    subgraph Presentación
        UI[CLI]
    end

    subgraph Orquestación
        AG[Agent]
        RT[Router]
        CTX[Memoria sesión]
        AUTH[Autenticación]
    end

    subgraph Lógica
        TOOLS[Tools]
        RAG[RAG]
    end

    subgraph Datos
        CSV[CSVs]
        MD[Markdown políticas]
    end

    subgraph Generación
        RESP[Response]
        LLM[GPT-4o]
    end

    UI --> AG
    AG --> RT
    AG --> CTX
    AG --> AUTH
    AG --> TOOLS
    AG --> RAG
    TOOLS --> CSV
    RAG --> MD
    AG --> RESP
    RESP --> LLM
```

---

## Estructura del proyecto

```
core/
│── agent.py          # Orquestador principal
│── router.py         # Clasificación de intención
│── auth.py           # Autenticación de usuarios
│── tools.py          # Acceso a datos (productos, pedidos, stock)
│── rag.py            # Recuperación de políticas (markdown)
│── response.py       # Generación de respuestas con LLM

data/
│── *.csv             # Datos de clientes, productos, pedidos, etc.

policies/
│── *.md              # Políticas de negocio

session_context.py    # Estado de sesión y trazabilidad
.env                  # Variables de entorno
```

---

## Autenticación

Para acceder a información de pedidos, el agente requiere:

* DNI
* Número de teléfono

La autenticación es:

* Multi-turno
* Persistente durante la sesión
* Validada contra `customers.csv`

---

## Trazabilidad

El sistema registra todas las acciones relevantes mediante:

* `add_tool_trace()`

Esto permite auditar:

* consultas a datos
* autenticación
* uso de LLM
* recuperación RAG

---

## Memoria conversacional

El agente mantiene una memoria ligera de sesión:

* intención previa
* dominio activo
* categoría o producto actual
* cliente autenticado
* últimos turnos

Esto permite:

* follow-ups naturales
* contexto conversacional coherente
* mejor experiencia de usuario

---

## Instalación

### 1. Descomprimir el proyecto

```bash
unzip challv2.zip
cd challv2
```

### 2. Crear entorno virtual (opcional)

```bash
python -m venv venv
venv\Scripts\activate
```

### 3. Instalar dependencias

```bash
pip install -r requirements.txt
```

---

## Variables de entorno

El proyecto incluye un archivo `.env` con la variable necesaria:

```
OPENAI_API_KEY=tu_api_key
```

Importante:

* La API Key de OpenAI será desactivada después de la fecha de evaluación del challenge.
* El sistema incluye un fallback local en caso de no disponibilidad del modelo.

---

## Ejecución

```bash
cd core
python agent.py
```

Para salir:

* salir
* exit
* quit

---

## Ejemplos de uso

```
Usuario: que vendes?
Usuario: que stocks tienes
Usuario: y en celulares?
Usuario: quiero ver mi pedido
Usuario: 123456789
Usuario: 3001234567
Usuario: tengo más pedidos?
```

---

## Tecnologías utilizadas

* Python 3.10+
* OpenAI GPT-4o (solo para generación de lenguaje)
* CSV como base de datos local
* RAG simple sobre markdown
* Arquitectura modular

--- 

## Decisiones de diseño

* LLM utilizado solo para redacción final
* Routing determinístico con fallback a LLM
* Sin embeddings ni bases vectoriales
* Memoria de sesión ligera
* Trazabilidad obligatoria

---

## Limitaciones

* Estado de sesión en memoria (no persistente)
* No diseñado para concurrencia multiusuario
* RAG basado en tokens, no embeddings

---

## Conclusión

El agente cumple con los requisitos del challenge:

* control de lógica
* autenticación
* trazabilidad
* uso de datos reales
* experiencia conversacional

El sistema está diseñado para ser eficiente, explicable y auditable.
