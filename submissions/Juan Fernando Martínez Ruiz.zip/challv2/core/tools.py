import csv
import re
import unicodedata
from pathlib import Path

from session_context import add_tool_trace

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CATEGORY_ALIASES = {
    "Electrónica": ["electronica", "tecnologia", "gadget"],
    "Electrodomésticos": ["electrodomestico", "electrodomesticos", "linea blanca"],
    "Hogar y Muebles": ["hogar", "muebles", "casa"],
    "Ropa y Calzado": ["ropa", "calzado", "moda"],
    "Deportes y Fitness": ["deportes", "fitness", "gym", "entrenamiento"],
    "Belleza y Cuidado Personal": ["belleza", "cuidado personal", "skincare"],
    "Libros y Papelería": ["libros", "papeleria", "escolar"],
    "Juguetes y Bebés": ["juguetes", "bebes", "bebe"],
}
SUBTYPE_ALIASES = {
    "celulares": ["celular", "celulares", "telefono", "telefonos", "smartphone", "smartphones", "iphone", "galaxy"],
    "laptops": ["laptop", "laptops", "portatil", "portatiles", "notebook", "computador", "computadores", "macbook"],
    "tablets": ["tablet", "tablets", "ipad"],
    "audifonos": ["audifono", "audifonos", "headphone", "headphones"],
    "televisores": ["tv", "televisor", "televisores", "smart tv"],
    "consolas": ["consola", "consolas", "playstation", "xbox"],
    "smartwatches": ["smartwatch", "smartwatches", "reloj inteligente", "banda", "pulsera inteligente"],
    "monitores": ["monitor", "monitores", "ultrawide"],
    "aspiradoras": ["aspiradora", "aspiradoras", "robot aspirador"],
    "neveras": ["nevera", "neveras", "refrigerador"],
}
SUBTYPE_CATEGORY_MAP = {
    "celulares": "Electrónica",
    "laptops": "Electrónica",
    "tablets": "Electrónica",
    "audifonos": "Electrónica",
    "televisores": "Electrónica",
    "consolas": "Electrónica",
    "smartwatches": "Electrónica",
    "monitores": "Electrónica",
    "aspiradoras": "Electrodomésticos",
    "neveras": "Electrodomésticos",
}
STOPWORDS = {
    "que", "mas", "más", "de", "del", "la", "el", "los", "las", "y", "en",
    "pero", "tienes", "tienen", "hay", "stock", "disponible", "disponibles",
    "quiero", "ver", "mostrar", "muestrame", "muéstrame", "productos",
}


def _normalize(value):
    text = str(value or "").strip().lower()
    text = unicodedata.normalize("NFD", text)
    return "".join(char for char in text if unicodedata.category(char) != "Mn")


def _tokens(value):
    return {token for token in re.findall(r"[a-z0-9]+", _normalize(value)) if len(token) > 1}


def _iter_csv(filename):
    with (DATA_DIR / filename).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            yield dict(row)


def _available_stock_for_product(product_id):
    total = 0
    for row in _iter_csv("stock.csv"):
        if row.get("product_id") == product_id:
            total += int(row.get("stock_qty") or 0) - int(row.get("reserved_qty") or 0)
    return total


def _product_maps():
    brands = {row["brand_id"]: row["name"] for row in _iter_csv("brands.csv")}
    categories = {row["category_id"]: row["name"] for row in _iter_csv("categories.csv")}
    return brands, categories


def _match_subtypes(text):
    normalized = _normalize(text)
    matches = []
    for subtype, aliases in SUBTYPE_ALIASES.items():
        if any(alias in normalized for alias in aliases):
            matches.append(subtype)
    return matches


def _product_matches_subtype(product, subtype):
    if not subtype:
        return True
    searchable = _normalize(
        " ".join(
            [
                product.get("name", ""),
                product.get("description", ""),
                product.get("specifications", ""),
            ]
        )
    )
    return any(alias in searchable for alias in SUBTYPE_ALIASES.get(subtype, []))


def _filter_products(products, brand_id=None, category_id=None, subtype=None):
    result = []
    for product in products:
        if brand_id and product.get("brand_id") != str(brand_id):
            continue
        if category_id and product.get("category_id") != str(category_id):
            continue
        if subtype and not _product_matches_subtype(product, subtype):
            continue
        result.append(product)
    return result


def obtener_cliente_por_dni(dni):
    dni = str(dni or "").strip()
    result = {}
    if dni:
        for row in _iter_csv("customers.csv"):
            if row.get("dni") == dni:
                result = row
                break
    add_tool_trace("obtener_cliente_por_dni", {"dni": dni}, result)
    return result


def obtener_pedidos_por_cliente(customer_id):
    customer_id = str(customer_id or "").strip()
    result = []
    if customer_id:
        for row in _iter_csv("orders.csv"):
            if row.get("customer_id") == customer_id:
                result.append(row)
    add_tool_trace("obtener_pedidos_por_cliente", {"customer_id": customer_id}, result)
    return result


def obtener_ultimo_pedido_cliente(customer_id):
    pedidos = obtener_pedidos_por_cliente(customer_id)
    pedidos.sort(key=lambda row: row.get("order_date") or "", reverse=True)
    result = pedidos[0] if pedidos else {}
    add_tool_trace(
        "obtener_ultimo_pedido_cliente",
        {"customer_id": str(customer_id or "").strip()},
        {"order_id": result.get("order_id") if result else None},
    )
    return result


def filtrar_pedidos_por_estado(customer_id, status):
    customer_id = str(customer_id or "").strip()
    status = _normalize(status)
    result = [
        row for row in obtener_pedidos_por_cliente(customer_id)
        if _normalize(row.get("status")) == status
    ]
    add_tool_trace(
        "filtrar_pedidos_por_estado",
        {"customer_id": customer_id, "status": status},
        {"order_ids": [row.get("order_id") for row in result]},
    )
    return result


def resumir_pedidos(pedidos, limit=5):
    limit = max(int(limit or 5), 1)
    pedidos_list = list(pedidos) if not isinstance(pedidos, list) else pedidos
    result = []
    for row in pedidos_list[:limit]:
        result.append(
            {
                "order_id": row.get("order_id"),
                "order_date": row.get("order_date"),
                "status": row.get("status"),
                "total_amount": row.get("total_amount"),
            }
        )
    add_tool_trace(
        "resumir_pedidos",
        {"limit": limit, "input_count": len(pedidos_list)},
        {"order_ids": [row.get("order_id") for row in result]},
    )
    return result


def resumir_stock_disponible(limit=5):
    brands, categories = _product_maps()
    category_summary = {}
    for product in _iter_csv("products.csv"):
        if product.get("active") != "true":
            continue
        available_stock = _available_stock_for_product(product.get("product_id"))
        if available_stock <= 0:
            continue
        category_name = categories.get(product.get("category_id"), "Sin categoría")
        entry = category_summary.setdefault(
            category_name,
            {"category_name": category_name, "available_products": 0, "sample_names": []},
        )
        entry["available_products"] += 1
        if len(entry["sample_names"]) < 2:
            entry["sample_names"].append(product.get("name"))
    result = sorted(category_summary.values(), key=lambda item: item["available_products"], reverse=True)[: max(int(limit or 5), 1)]
    add_tool_trace(
        "resumir_stock_disponible",
        {"limit": limit},
        {"categories": [item.get("category_name") for item in result]},
    )
    return result


def obtener_estado_pedido(order_id):
    order_id = str(order_id or "").strip()
    order = {}
    shipment = {}
    latest_tracking = {}

    if order_id:
        for row in _iter_csv("orders.csv"):
            if row.get("order_id") == order_id:
                order = row
                break
        for row in _iter_csv("shipments.csv"):
            if row.get("order_id") == order_id:
                shipment = row
                break
        for row in _iter_csv("tracking.csv"):
            if row.get("order_id") == order_id:
                if not latest_tracking or row.get("timestamp", "") >= latest_tracking.get("timestamp", ""):
                    latest_tracking = row

    result = {
        "order": order,
        "shipment": shipment,
        "latest_tracking": latest_tracking,
    }
    add_tool_trace("obtener_estado_pedido", {"order_id": order_id}, result)
    return result


def obtener_detalle_pedido(order_id):
    order_id = str(order_id or "").strip()
    order = {}
    items = []
    product_ids = set()
    products = {}
    shipment = {}
    tracking = []

    if order_id:
        for row in _iter_csv("orders.csv"):
            if row.get("order_id") == order_id:
                order = row
                break
        for row in _iter_csv("order_items.csv"):
            if row.get("order_id") == order_id:
                items.append(row)
                if row.get("product_id"):
                    product_ids.add(row.get("product_id"))
        if product_ids:
            for row in _iter_csv("products.csv"):
                product_id = row.get("product_id")
                if product_id in product_ids:
                    products[product_id] = row
        for item in items:
            item["product"] = products.get(item.get("product_id"), {})
        for row in _iter_csv("shipments.csv"):
            if row.get("order_id") == order_id:
                shipment = row
                break
        for row in _iter_csv("tracking.csv"):
            if row.get("order_id") == order_id:
                tracking.append(row)

    result = {
        "order": order,
        "items": items,
        "shipment": shipment,
        "tracking": tracking,
    }
    add_tool_trace("obtener_detalle_pedido", {"order_id": order_id}, result)
    return result


def resolver_categoria_o_marca_desde_query(query, context_entities=None):
    normalized = _normalize(query)
    brands, categories = _product_maps()

    matched_categories = []
    for category_id, category_name in categories.items():
        alias_tokens = CATEGORY_ALIASES.get(category_name, [])
        if _normalize(category_name) in normalized or any(alias in normalized for alias in alias_tokens):
            matched_categories.append({"category_id": category_id, "name": category_name})

    matched_brands = []
    query_tokens = {token for token in _tokens(query) if token not in STOPWORDS}
    for brand_id, brand_name in brands.items():
        brand_tokens = _tokens(brand_name)
        if brand_tokens and brand_tokens.issubset(query_tokens):
            matched_brands.append({"brand_id": brand_id, "name": brand_name})

    product_matches = []
    if query_tokens:
        for product in _iter_csv("products.csv"):
            searchable = _tokens(product.get("name", ""))
            score = len(query_tokens & searchable)
            product_name_normalized = _normalize(product.get("name", ""))
            if score > 1 or (product_name_normalized and product_name_normalized in normalized):
                product_matches.append((score, product))
        product_matches.sort(key=lambda item: item[0], reverse=True)
        product_matches = [
            {
                "product_id": item[1].get("product_id"),
                "name": item[1].get("name"),
                "brand_id": item[1].get("brand_id"),
                "category_id": item[1].get("category_id"),
            }
            for item in product_matches[:3]
        ]

    matched_subtypes = [{"name": subtype} for subtype in _match_subtypes(query)]
    if matched_subtypes and not matched_categories:
        inferred_category_name = SUBTYPE_CATEGORY_MAP.get(matched_subtypes[0]["name"])
        for category_id, category_name in categories.items():
            if inferred_category_name and _normalize(category_name) == _normalize(inferred_category_name):
                matched_categories = [{"category_id": category_id, "name": category_name}]
                break

    if context_entities and not matched_categories:
        matched_categories = list(context_entities.get("categories", []))
    if context_entities and not matched_brands:
        matched_brands = list(context_entities.get("brands", []))
    if context_entities and not product_matches:
        product_matches = list(context_entities.get("products", []))
    if context_entities and not matched_subtypes:
        matched_subtypes = list(context_entities.get("subtypes", []))
    if matched_subtypes and product_matches:
        subtype_name = matched_subtypes[0]["name"]
        filtered_matches = []
        product_map = {product.get("product_id"): product for product in _iter_csv("products.csv")}
        for item in product_matches:
            product = product_map.get(item.get("product_id"), {})
            if product and _product_matches_subtype(product, subtype_name):
                filtered_matches.append(item)
        product_matches = filtered_matches

    result = {
        "categories": matched_categories,
        "brands": matched_brands,
        "products": product_matches,
        "subtypes": matched_subtypes,
    }
    add_tool_trace("resolver_categoria_o_marca_desde_query", {"query": query}, result)
    return result


def buscar_productos_catalogo(query="", brand_id=None, category_id=None, subtype=None, limit=5):
    query_tokens = {token for token in _tokens(query) if token not in STOPWORDS}
    products = [row for row in _iter_csv("products.csv") if row.get("active") == "true"]
    filtered = _filter_products(products, brand_id=brand_id, category_id=category_id, subtype=subtype)
    scored = []
    for product in filtered:
        searchable = " ".join(
            [
                product.get("name", ""),
                product.get("description", ""),
                product.get("specifications", ""),
            ]
        )
        score = len(query_tokens & _tokens(searchable)) if query_tokens else 1
        if score:
            scored.append((score, product))
    scored.sort(key=lambda item: item[0], reverse=True)
    result = [item[1] for item in scored[: max(int(limit or 5), 1)]]
    if not result and filtered:
        result = filtered[: max(int(limit or 5), 1)]
    add_tool_trace(
        "buscar_productos_catalogo",
        {"query": query, "brand_id": brand_id, "category_id": category_id, "subtype": subtype, "limit": limit},
        {"product_ids": [item.get("product_id") for item in result]},
    )
    return result


def obtener_productos_economicos(limit=5, brand_id=None, category_id=None, subtype=None):
    filtered = _filter_products(
        [row for row in _iter_csv("products.csv") if row.get("active") == "true"],
        brand_id=brand_id,
        category_id=category_id,
        subtype=subtype,
    )
    filtered.sort(key=lambda item: float(item.get("price") or 0))
    result = filtered[: max(int(limit or 5), 1)]
    add_tool_trace(
        "obtener_productos_economicos",
        {"limit": limit, "brand_id": brand_id, "category_id": category_id, "subtype": subtype},
        {"product_ids": [item.get("product_id") for item in result]},
    )
    return result


def filtrar_por_subtipo_activo(productos, subtype):
    subtype = str(subtype or "").strip()
    products_list = list(productos) if not isinstance(productos, list) else productos
    if not subtype:
        result = list(products_list)
    else:
        result = [product for product in products_list if _product_matches_subtype(product, subtype)]
    add_tool_trace(
        "filtrar_por_subtipo_activo",
        {"subtype": subtype, "input_count": len(products_list)},
        {"product_ids": [item.get("product_id") for item in result[:10]]},
    )
    return result


def obtener_productos_relacionados_misma_categoria(category_id, exclude_product_id=None, subtype=None, limit=5):
    category_id = str(category_id or "").strip()
    exclude_product_id = str(exclude_product_id or "").strip()
    products = [
        row for row in _iter_csv("products.csv")
        if row.get("active") == "true" and row.get("category_id") == category_id and row.get("product_id") != exclude_product_id
    ]
    result = filtrar_por_subtipo_activo(products, subtype)[: max(int(limit or 5), 1)]
    add_tool_trace(
        "obtener_productos_relacionados_misma_categoria",
        {"category_id": category_id, "exclude_product_id": exclude_product_id, "subtype": subtype, "limit": limit},
        {"product_ids": [item.get("product_id") for item in result]},
    )
    return result


def obtener_productos_relacionados_misma_marca(brand_id, exclude_product_id=None, category_id=None, subtype=None, limit=5):
    brand_id = str(brand_id or "").strip()
    exclude_product_id = str(exclude_product_id or "").strip()
    category_id = str(category_id or "").strip()
    products = [
        row for row in _iter_csv("products.csv")
        if row.get("active") == "true"
        and row.get("brand_id") == brand_id
        and row.get("product_id") != exclude_product_id
        and (not category_id or row.get("category_id") == category_id)
    ]
    result = filtrar_por_subtipo_activo(products, subtype)[: max(int(limit or 5), 1)]
    add_tool_trace(
        "obtener_productos_relacionados_misma_marca",
        {
            "brand_id": brand_id,
            "exclude_product_id": exclude_product_id,
            "category_id": category_id,
            "subtype": subtype,
            "limit": limit,
        },
        {"product_ids": [item.get("product_id") for item in result]},
    )
    return result


def obtener_alternativas_al_producto_actual(product_id, limit=5, brand_id=None, category_id=None, subtype=None):
    product_id = str(product_id or "").strip()
    category_options = obtener_productos_relacionados_misma_categoria(
        category_id,
        exclude_product_id=product_id,
        subtype=subtype,
        limit=limit,
    ) if category_id else []
    if len(category_options) >= max(int(limit or 5), 1):
        result = category_options[: max(int(limit or 5), 1)]
    else:
        seen_ids = {item.get("product_id") for item in category_options}
        brand_options = obtener_productos_relacionados_misma_marca(
            brand_id,
            exclude_product_id=product_id,
            category_id=category_id,
            subtype=subtype,
            limit=limit,
        ) if brand_id else []
        result = list(category_options)
        for item in brand_options:
            if item.get("product_id") not in seen_ids:
                result.append(item)
            if len(result) >= max(int(limit or 5), 1):
                break
    add_tool_trace(
        "obtener_alternativas_al_producto_actual",
        {"product_id": product_id, "brand_id": brand_id, "category_id": category_id, "subtype": subtype, "limit": limit},
        {"product_ids": [item.get("product_id") for item in result]},
    )
    return result


def obtener_promociones_activas():
    result = []
    for row in _iter_csv("promotions.csv"):
        if row.get("active", "").lower() == "true":
            result.append(row)
    add_tool_trace("obtener_promociones_activas", {}, result)
    return result


def filtrar_promociones_por_categoria(category_id, subtype=None):
    category_id = str(category_id or "").strip()
    category_product_ids = {
        product.get("product_id")
        for product in _filter_products(_iter_csv("products.csv"), category_id=category_id, subtype=subtype)
        if product.get("product_id")
    }
    result = []
    for promo in obtener_promociones_activas():
        category_ids = [item.strip() for item in str(promo.get("applicable_category_ids") or "").split(",") if item.strip()]
        promo_product_ids = {
            item.strip()
            for item in re.split(r"[|,]", str(promo.get("applicable_product_ids") or ""))
            if item.strip()
        }
        if category_id in category_ids or promo_product_ids.intersection(category_product_ids):
            result.append(promo)
    add_tool_trace("filtrar_promociones_por_categoria", {"category_id": category_id, "subtype": subtype}, result)
    return result


def filtrar_promociones_por_marca(brand_id, subtype=None):
    brand_id = str(brand_id or "").strip()
    brand_product_ids = set()
    brand_category_ids = set()
    for product in _iter_csv("products.csv"):
        if product.get("brand_id") == brand_id and _product_matches_subtype(product, subtype):
            brand_product_ids.add(product.get("product_id"))
            if product.get("category_id"):
                brand_category_ids.add(product.get("category_id"))

    result = []
    for promo in obtener_promociones_activas():
        promo_product_ids = {
            item.strip()
            for item in re.split(r"[|,]", str(promo.get("applicable_product_ids") or ""))
            if item.strip()
        }
        promo_category_ids = {
            item.strip()
            for item in re.split(r"[|,]", str(promo.get("applicable_category_ids") or ""))
            if item.strip()
        }
        if promo_product_ids.intersection(brand_product_ids) or promo_category_ids.intersection(brand_category_ids):
            result.append(promo)
    add_tool_trace("filtrar_promociones_por_marca", {"brand_id": brand_id, "subtype": subtype}, result)
    return result


def obtener_stock_por_producto(product_id):
    product_id = str(product_id or "").strip()
    brands, categories = _product_maps()
    product = {}
    for row in _iter_csv("products.csv"):
        if row.get("product_id") == product_id:
            product = row
            break
    result = {
        "product": product,
        "available_stock": _available_stock_for_product(product_id),
        "brand_name": brands.get(product.get("brand_id")) if product else None,
        "category_name": categories.get(product.get("category_id")) if product else None,
    }
    add_tool_trace("obtener_stock_por_producto", {"product_id": product_id}, result)
    return result


def obtener_stock_por_categoria(category_id, subtype=None):
    category_id = str(category_id or "").strip()
    brands, categories = _product_maps()
    result = []
    for product in _iter_csv("products.csv"):
        if product.get("category_id") == category_id and product.get("active") == "true" and _product_matches_subtype(product, subtype):
            result.append(
                {
                    "product_id": product.get("product_id"),
                    "name": product.get("name"),
                    "brand_name": brands.get(product.get("brand_id")),
                    "category_name": categories.get(category_id),
                    "available_stock": _available_stock_for_product(product.get("product_id")),
                }
            )
    add_tool_trace("obtener_stock_por_categoria", {"category_id": category_id, "subtype": subtype}, result)
    return result


def obtener_stock_por_marca(brand_id, subtype=None):
    brand_id = str(brand_id or "").strip()
    brands, categories = _product_maps()
    result = []
    for product in _iter_csv("products.csv"):
        if product.get("brand_id") == brand_id and product.get("active") == "true" and _product_matches_subtype(product, subtype):
            result.append(
                {
                    "product_id": product.get("product_id"),
                    "name": product.get("name"),
                    "brand_name": brands.get(brand_id),
                    "category_name": categories.get(product.get("category_id")),
                    "available_stock": _available_stock_for_product(product.get("product_id")),
                }
            )
    add_tool_trace("obtener_stock_por_marca", {"brand_id": brand_id, "subtype": subtype}, result)
    return result
