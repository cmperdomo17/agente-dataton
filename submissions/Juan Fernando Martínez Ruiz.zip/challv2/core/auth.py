import re

from core.tools import obtener_cliente_por_dni
from session_context import add_tool_trace, set_session_customer


def _digits(value):
    return "".join(char for char in str(value or "") if char.isdigit())


def _same_phone(left, right):
    left_digits = _digits(left)
    right_digits = _digits(right)
    if not left_digits or not right_digits:
        return False
    if left_digits == right_digits:
        return True
    return left_digits.endswith(right_digits) or right_digits.endswith(left_digits)


def _extract_dni(text):
    match = re.search(r"(?:dni|cedula|c[ .-]*c)\D{0,12}(\d{5,})", str(text or ""), re.IGNORECASE)
    return match.group(1) if match else ""


def _extract_phone(text):
    patterns = [
        r"(?:phone|telefono|tel|celular|cel)\D{0,12}(\+?\d[\d\s-]{7,}\d)",
        r"(\+?57[\s-]*\d{3}[\s-]*\d{3}[\s-]*\d{4})",
    ]
    raw_text = str(text or "")
    for pattern in patterns:
        match = re.search(pattern, raw_text, re.IGNORECASE)
        if match:
            return _digits(match.group(1))
    return ""


def extract_auth_fields(user_input, loose=False):
    dni = _extract_dni(user_input)
    phone = _extract_phone(user_input)
    if loose and not (dni or phone):
        digits = _digits(user_input)
        if len(digits) >= 8:
            if digits.startswith("3") and len(digits) in {10, 12}:
                phone = digits
            else:
                dni = digits
    return {"dni": dni, "phone": phone}


def looks_like_auth_payload(user_input):
    fields = extract_auth_fields(user_input)
    return bool(fields["dni"] or fields["phone"])


def authenticate_credentials(dni, phone):
    dni = str(dni or "").strip()
    phone = str(phone or "").strip()
    if not (dni and phone):
        return False, ""

    customer = obtener_cliente_por_dni(dni)
    valid = bool(customer) and _same_phone(customer.get("phone"), phone)
    customer_id = customer.get("customer_id") if valid else None
    display_name = " ".join(
        part for part in [customer.get("name"), customer.get("last_name1"), customer.get("last_name2")] if part
    ) if valid else ""

    add_tool_trace(
        "authenticate_customer",
        {"dni": dni or None, "phone": phone or None},
        {"authenticated": valid, "customer_id": customer_id},
    )

    if not valid:
        return True, "No pude autenticarte. Verifica tu dni y phone para continuar."

    set_session_customer(customer_id, display_name)
    return True, f"Autenticacion exitosa. Sesion iniciada para {display_name}."


def authenticate_user_input(user_input):
    fields = extract_auth_fields(user_input)
    dni = fields["dni"]
    phone = fields["phone"]
    attempted = bool(dni or phone)
    if not attempted:
        return False, ""
    if not (dni and phone):
        return True, "Para autenticarte necesito tu dni y phone."
    return authenticate_credentials(dni, phone)
