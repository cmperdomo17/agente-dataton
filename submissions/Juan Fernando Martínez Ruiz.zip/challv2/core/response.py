import json
import os
import re
from pathlib import Path
from urllib import error, request

from session_context import add_tool_trace

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_env_value(name):
    value = os.getenv(name)
    if value:
        return value
    env_path = BASE_DIR / ".env"
    if not env_path.exists():
        return ""
    for line in env_path.read_text(encoding="utf-8").splitlines():
        if line.startswith(f"{name}="):
            return line.split("=", 1)[1].strip()
    return ""


def _fallback_text(data):
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return str(data.get("respuesta_base") or data.get("response") or "")
    return str(data or "")


def _plain_text(value):
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text.replace("|", " ").replace("**", "").replace("*", " ").replace("`", "").replace("---", "")


def _fallback_response(intent, data):
    if intent in {"POLITICAS", "FAQ"} and isinstance(data, dict) and data.get("secciones"):
        parts = []
        for item in data.get("secciones", [])[:2]:
            title = _plain_text(item.get("title"))
            content = _plain_text(item.get("content"))[:260]
            if title and content:
                parts.append(f"{title}: {content}")
        if parts:
            return " ".join(parts)
    return _plain_text(_fallback_text(data))[:900]


def _compact_data(intent, data):
    if not isinstance(data, dict):
        return {"respuesta_base": _plain_text(_fallback_text(data))[:700]}

    compact = {}
    if intent in {"POLITICAS", "FAQ"} and data.get("secciones"):
        compact["secciones"] = [
            {
                "titulo": _plain_text(item.get("title")),
                "contenido": _plain_text(item.get("content"))[:420],
            }
            for item in data.get("secciones", [])[:2]
        ]
    else:
        compact["respuesta_base"] = _plain_text(_fallback_text(data))[:800]

    if data.get("response_kind"):
        compact["response_kind"] = data.get("response_kind")
    if data.get("domain"):
        compact["domain"] = data.get("domain")
    if data.get("topic"):
        compact["topic"] = data.get("topic")
    if data.get("active_category"):
        compact["active_category"] = data.get("active_category")
    if data.get("active_subtype"):
        compact["active_subtype"] = data.get("active_subtype")
    if data.get("active_brand"):
        compact["active_brand"] = data.get("active_brand")
    if data.get("active_result_scope"):
        compact["active_result_scope"] = data.get("active_result_scope")
    if data.get("entities"):
        compact["entities"] = data.get("entities")
    if data.get("last_result_type"):
        compact["last_result_type"] = data.get("last_result_type")
    if data.get("last_result_summary"):
        compact["last_result_summary"] = _plain_text(data.get("last_result_summary"))[:220]
    if data.get("recent_context"):
        compact["recent_context"] = [
            {
                "user": _plain_text(item.get("user"))[:120],
                "assistant": _plain_text(item.get("assistant"))[:180],
            }
            for item in data.get("recent_context", [])[:3]
        ]
    return compact


def _system_prompt(intent, data):
    response_kind = data.get("response_kind") if isinstance(data, dict) else ""
    product_detail = ""
    policy_detail = ""
    order_detail = ""
    if response_kind == "promotion":
        product_detail = "La respuesta debe sonar como una orientacion sobre promociones o descuentos reales. "
    elif response_kind == "stock_general":
        product_detail = "Si la pregunta es general de stock, responde primero con un panorama general y ofrece profundizar. "
    elif response_kind == "stock_category":
        product_detail = "Si la pregunta es por categoria o tipo, responde solo dentro de esa categoria y limita la lista a pocos ejemplos claros. "
    elif response_kind == "stock_brand":
        product_detail = "Si la pregunta es por marca, resume solo productos de esa marca con stock real. "
    elif response_kind == "stock_product" or response_kind == "stock":
        product_detail = "La respuesta debe dejar claro el stock o disponibilidad real sin sonar robótica. "
    elif response_kind == "product_catalog":
        product_detail = "Si la consulta es amplia o coloquial, responde primero con panorama breve y ejemplos utiles, sin elegir un solo producto arbitrariamente. "
    elif response_kind == "lista_misma_marca":
        product_detail = "La respuesta debe quedarse dentro de la misma marca y familia activa, sin mezclar productos irrelevantes. "
    elif response_kind == "lista_misma_categoria":
        product_detail = "La respuesta debe quedarse dentro de la misma familia activa y presentar alternativas claras sin mezclar categorias irrelevantes. "
    elif response_kind == "product":
        product_detail = "La respuesta debe presentar el producto o catalogo de forma clara y cercana. "
    elif response_kind == "order_history":
        order_detail = "Si se listan varios pedidos, resume maximo 2 a 5, suena paciente y deja abierta una continuacion breve. "
    elif response_kind == "order_count":
        order_detail = "Responde de forma directa sobre cantidad o si hay mas pedidos, sin repetir el detalle del pedido actual. "
    elif response_kind == "order_last":
        order_detail = "Aclara que se trata del pedido mas reciente. "
    elif response_kind == "order_detail":
        order_detail = "Resume el detalle del pedido sin enumerar mas de tres productos. "
    if response_kind == "policy_general":
        policy_detail = "Resume brevemente las tres areas por separado: devoluciones, garantia y envios. "
    elif response_kind == "policy_returns":
        policy_detail = "Enfocate solo en devoluciones y cambios. "
    elif response_kind == "policy_warranty":
        policy_detail = "Enfocate solo en garantia. "
    elif response_kind == "policy_shipping":
        policy_detail = "Enfocate solo en envios, tiempos y logistica. "
    elif response_kind == "policy_specific":
        policy_detail = "Enfocate solo en el tema recuperado sin mezclar otras politicas. "

    prompts = {
        "FAQ": (
            "Eres un asistente de e-commerce cercano y profesional. Responde en espanol, breve y util. "
            "Tolera lenguaje corto, coloquial o ambiguo usando el contexto entregado si alcanza. "
            "Usa solo los datos entregados. Si es saludo, ofrece ayuda con politicas, productos, promociones, stock o pedidos autenticados."
        ),
        "POLITICAS": (
            "Resume politicas en espanol natural y breve. Usa solo los datos entregados. "
            f"{policy_detail}"
            "No pegues bloques largos, tablas completas ni texto crudo. "
            "Si la consulta es general, resume devoluciones, garantia y envios por separado. "
            "Si la consulta es especifica, enfocate solo en ese tema y no mezcles otros. "
            "Menciona condiciones clave, exclusiones y siguiente paso util si aparece en los datos."
        ),
        "PRODUCTOS": (
            "Redacta una respuesta clara, conversacional y breve sobre catalogo, stock o promociones. "
            f"{product_detail}"
            "Si la pregunta es corta o ambigua, usa el contexto entregado antes de pedir aclaracion. "
            "Usa solo los datos entregados y no inventes precio, disponibilidad, descuentos ni caracteristicas faltantes."
        ),
        "PEDIDO_MONTO": (
            "Explica el monto del pedido con tono calido y breve. Usa solo los datos entregados. "
            f"{order_detail}"
            "No agregues cargos, descuentos ni supuestos."
        ),
        "PEDIDO_ESTADO": (
            "Explica el estado del pedido con tono calido y breve. Usa solo los datos entregados. "
            f"{order_detail}"
            "Si la pregunta es corta pero el contexto alcanza, responde sin pedir aclaraciones innecesarias. "
            "No prometas fechas ni acciones que no esten en los datos."
        ),
    }
    return prompts.get(intent, prompts["FAQ"])


def generar_respuesta_final(user_input, intent, data):
    fallback = _fallback_response(intent, data)
    api_key = _load_env_value("OPENAI_API_KEY")
    if not api_key or not fallback:
        return fallback

    model = _load_env_value("OPENAI_MODEL") or "gpt-4o"
    compact_data = _compact_data(intent, data)
    context = json.dumps(compact_data, ensure_ascii=False, separators=(",", ":"))[:1700]
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": _system_prompt(intent, data if isinstance(data, dict) else {}),
            },
            {
                "role": "user",
                "content": f"Pregunta: {str(user_input or '')[:240]}\nIntencion: {intent}\nDatos: {context}",
            },
        ],
        "temperature": 0.35,
        "max_tokens": 150,
    }
    req = request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=6) as response:
            result = json.loads(response.read().decode("utf-8"))
        text = result["choices"][0]["message"]["content"].strip()
        add_tool_trace(
            "generar_respuesta_final",
            {"intent": intent, "model": model, "data": compact_data},
            {"response": text},
        )
        return text or fallback
    except (error.URLError, error.HTTPError, KeyError, IndexError, json.JSONDecodeError, TimeoutError):
        add_tool_trace(
            "generar_respuesta_final",
            {"intent": intent, "model": model, "data": compact_data},
            {"response": fallback, "fallback": True},
        )
        return fallback
