import re
import unicodedata
from pathlib import Path

from session_context import add_tool_trace

BASE_DIR = Path(__file__).resolve().parent.parent
POLICY_DIR = BASE_DIR / "policies"


def _normalize(value):
    text = str(value or "").strip().lower()
    text = unicodedata.normalize("NFD", text)
    return "".join(char for char in text if unicodedata.category(char) != "Mn")


def _tokens(value):
    return {token for token in re.findall(r"[a-z0-9]+", _normalize(value)) if len(token) > 1}


def _bucket(value):
    text = _normalize(value)
    has_general = any(term in text for term in ("politica", "politicas", "condicion", "condiciones"))
    has_returns = any(term in text for term in ("devol", "refund", "reembolso", "cambio", "cancel", "return"))
    has_warranty = any(term in text for term in ("garant", "warranty", "falla", "defect", "reparacion"))
    has_shipping = any(term in text for term in ("envio", "env", "shipping", "entrega", "tracking", "direccion", "factura", "despacho"))
    specific_count = sum([has_returns, has_warranty, has_shipping])
    if specific_count > 1 or (has_general and specific_count == 0):
        return "general"
    if has_returns:
        return "returns"
    if has_warranty:
        return "warranty"
    if has_shipping:
        return "shipping"
    return ""


def _bucket_for_file(path):
    filename = _normalize(path.name)
    if any(term in filename for term in ("devol", "cambio", "refund", "return")):
        return "returns"
    if any(term in filename for term in ("garant", "warranty")):
        return "warranty"
    if any(term in filename for term in ("envio", "shipping", "entrega", "despacho")):
        return "shipping"
    return ""


def _policy_files():
    if not POLICY_DIR.exists():
        return []
    return sorted(path for path in POLICY_DIR.iterdir() if path.is_file() and path.suffix.lower() == ".md")


def _dividir_por_titulos(markdown_text):
    sections = []
    current_title = ""
    current_lines = []
    for raw_line in markdown_text.splitlines():
        line = raw_line.strip()
        if line.startswith("##"):
            if current_lines:
                sections.append({"title": current_title, "content": "\n".join(current_lines).strip()})
            current_title = re.sub(r"^#+\s*", "", line).strip("* ").strip()
            current_lines = []
            continue
        if current_title and line:
            current_lines.append(line)
    if current_lines:
        sections.append({"title": current_title, "content": "\n".join(current_lines).strip()})
    return sections


def recuperar_politica(query):
    query_tokens = _tokens(query)
    query_bucket = _bucket(query)
    if not query_tokens:
        add_tool_trace("recuperar_politica", {"query": query}, {"matches": []})
        return []

    matches = []
    for path in _policy_files():
        document = path.read_text(encoding="utf-8", errors="replace")
        doc_bucket = _bucket_for_file(path) or _bucket(document[:800])
        if query_bucket and query_bucket != "general" and doc_bucket and query_bucket != doc_bucket:
            continue
        for section in _dividir_por_titulos(document):
            combined = f'{section["title"]}\n{section["content"]}'
            score = len(query_tokens & _tokens(combined))
            if query_bucket == "general":
                score += 1
            if query_bucket and query_bucket == doc_bucket:
                score += 2
            if score:
                matches.append(
                    {
                        "document": path.name,
                        "bucket": doc_bucket or None,
                        "title": section["title"],
                        "content": re.sub(r"\s+", " ", section["content"]).strip()[:900],
                        "score": score,
                    }
                )
    matches.sort(key=lambda item: item["score"], reverse=True)
    if query_bucket == "general":
        result = []
        seen_buckets = set()
        for item in matches:
            bucket = item.get("bucket") or item["document"]
            if bucket in seen_buckets:
                continue
            result.append(item)
            seen_buckets.add(bucket)
            if len(result) == 3:
                break
        if len(result) < 2:
            result = matches[:3]
    else:
        result = matches[:2]
    add_tool_trace(
        "recuperar_politica",
        {"query": query, "bucket": query_bucket or None},
        {"matches": [{"document": item["document"], "title": item["title"]} for item in result]},
    )
    return result


