import json
import os
import unicodedata
from pathlib import Path
from urllib import error, request

from session_context import add_tool_trace

BASE_DIR = Path(__file__).resolve().parent.parent
INTENT_CATEGORIES = (
    "FAQ",
    "POLITICAS",
    "PRODUCTOS",
    "PEDIDO_MONTO",
    "PEDIDO_ESTADO",
)


def _normalize(value):
    text = str(value or "").strip().lower()
    text = unicodedata.normalize("NFD", text)
    return "".join(char for char in text if unicodedata.category(char) != "Mn")


def _normalize_user_input(value):
    text = _normalize(value)
    replacements = {
        " q ": " que ",
        " pa ": " para ",
        " stok ": " stock ",
        " promo ": " promocion ",
        " promos ": " promociones ",
        " cel ": " celular ",
        " celu ": " celular ",
        " tv ": " televisor ",
        " compu ": " computador ",
        " pc ": " computador ",
        " ey ": " hey ",
    }
    text = f" {text} "
    for source, target in replacements.items():
        text = text.replace(source, target)
    text = text.replace("holaaa", "hola").replace("holaa", "hola").replace("buenass", "buenas")
    return " ".join(text.split())


def _contains_any(text, keywords):
    return any(keyword in text for keyword in keywords)


def _load_env_value(name):
    value = os.getenv(name)
    if value:
        return value
    env_path = BASE_DIR / ".env"
    if not env_path.exists():
        return ""
    for line in env_path.read_text(encoding="utf-8").splitlines():
        if line.startswith(f"{name}="):
            return line.split("=", 1)[1].strip()
    return ""


def _deterministic_route(user_input):
    text = _normalize_user_input(user_input)
    if not text:
        return "FAQ"

    greeting_terms = ("hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "hey", "hello", "holi")
    followup_terms = ("y ", "y los", "y las", "y el", "y la", "pero", "tambien", "también")
    vague_followups = ("ese", "esos", "esa", "esas", "otros", "otras", "ademas de ese", "solo ese", "mas opciones", "otros modelos")
    order_terms = ("pedido", "orden", "compra", "order", "tracking", "guia", "rastreo")
    amount_terms = ("monto", "total", "valor", "cuanto pague", "cuanto costo", "cobro", "cargo", "subtotal", "impuesto")
    status_terms = ("estado", "donde", "cuando llega", "cuando entrega", "entregado", "enviado", "cancelado", "demorado", "guia", "rastreo")
    policy_terms = (
        "politica", "politicas", "condicion", "condiciones", "devolucion", "devoluciones",
        "garantia", "garantias", "reembolso", "cambio", "cambios", "envio", "envios"
    )
    promo_terms = ("descuento", "descuentos", "promocion", "promociones", "promo", "oferta", "ofertas")
    stock_terms = ("stock", "disponible", "disponibilidad", "hay", "inventario")
    product_terms = ("producto", "productos", "precio", "catalogo", "marca", "modelo", "especific", "celular", "celulares", "vendes", "vende", "tienes", "barato", "economico", "muestrame")
    faq_terms = ("ayuda", "soporte", "contacto", "horario", "metodos de pago", "medios de pago", "faq")

    if text in greeting_terms or text.startswith(greeting_terms):
        return "FAQ"
    if len(text.split()) <= 5 and (_contains_any(text, vague_followups) or text.startswith(followup_terms)):
        return "FAQ"
    if _contains_any(text, policy_terms):
        return "POLITICAS"
    if _contains_any(text, promo_terms):
        return "PRODUCTOS"
    if _contains_any(text, order_terms) and _contains_any(text, amount_terms):
        return "PEDIDO_MONTO"
    if _contains_any(text, order_terms) and _contains_any(text, status_terms):
        return "PEDIDO_ESTADO"
    if "mi pedido" in text or "my order" in text:
        return "PEDIDO_ESTADO"
    if _contains_any(text, stock_terms) or _contains_any(text, product_terms):
        return "PRODUCTOS"
    if _contains_any(text, faq_terms):
        return "FAQ"
    if len(text.split()) <= 4 and text.startswith(followup_terms):
        return "FAQ"
    return ""


def _llm_route(user_input):
    api_key = _load_env_value("OPENAI_API_KEY")
    model = _load_env_value("OPENAI_MODEL") or "gpt-4o-mini"
    if not api_key:
        return ""

    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Clasifica el mensaje en una sola categoria exacta: "
                    "FAQ, POLITICAS, PRODUCTOS, PEDIDO_MONTO, PEDIDO_ESTADO. "
                    "Responde solo con una categoria."
                ),
            },
            {"role": "user", "content": str(user_input or "")},
        ],
        "temperature": 0,
        "max_tokens": 8,
    }
    req = request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
        content = data["choices"][0]["message"]["content"].strip().upper()
        category = content if content in INTENT_CATEGORIES else ""
        add_tool_trace(
            "route_intent_llm",
            {"user_input": user_input, "model": model},
            {"category": category or "FAQ"},
        )
        return category
    except (error.URLError, error.HTTPError, KeyError, IndexError, json.JSONDecodeError, TimeoutError):
        return ""


def route_intent(user_input):
    category = _deterministic_route(user_input)
    if category:
        return category
    return _llm_route(user_input) or "FAQ"
