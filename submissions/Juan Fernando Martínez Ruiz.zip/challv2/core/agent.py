import re
import sys
from pathlib import Path

if __package__ in {None, ''}:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import unicodedata
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from core.auth import authenticate_credentials, extract_auth_fields, looks_like_auth_payload
from core.rag import recuperar_politica
from core.response import generar_respuesta_final
from core.router import route_intent
from core.tools import (
    _iter_csv,
    buscar_productos_catalogo,
    filtrar_promociones_por_categoria,
    filtrar_promociones_por_marca,
    filtrar_por_subtipo_activo,
    filtrar_pedidos_por_estado,
    obtener_alternativas_al_producto_actual,
    obtener_detalle_pedido,
    obtener_estado_pedido,
    obtener_ultimo_pedido_cliente,
    obtener_pedidos_por_cliente,
    obtener_productos_economicos,
    obtener_productos_relacionados_misma_categoria,
    obtener_productos_relacionados_misma_marca,
    obtener_promociones_activas,
    obtener_stock_por_categoria,
    obtener_stock_por_marca,
    obtener_stock_por_producto,
    resumir_stock_disponible,
    resolver_categoria_o_marca_desde_query,
    resumir_pedidos,
)
from session_context import get_session_context, get_session_customer, reset_session, update_session_context


def _normalize(value):
    text = str(value or "").strip().lower()
    text = unicodedata.normalize("NFD", text)
    return "".join(char for char in text if unicodedata.category(char) != "Mn")


def _normalize_user_input(value):
    text = _normalize(value)
    replacements = {
        r"\bq\b": "que",
        r"\bk\b": "que",
        r"\bpa\b": "para",
        r"\bstok\b": "stock",
        r"\bpromo\b": "promocion",
        r"\bpromos\b": "promociones",
        r"\bcel\b": "celular",
        r"\bcelu\b": "celular",
        r"\btv\b": "televisor",
        r"\bcompu\b": "computador",
        r"\bpc\b": "computador",
        r"\bey\b": "hey",
        r"\baja\b": "si",
        r"\bmuestreme\b": "muestrame",
        r"\basi\b": "asi",
    }
    for pattern, replacement in replacements.items():
        text = re.sub(pattern, replacement, text)
    text = re.sub(r"\bhola+\b", "hola", text)
    text = re.sub(r"\bbuenas+\b", "buenas", text)
    text = re.sub(r"\bholi+\b", "holi", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _tokens(value):
    return {token for token in re.findall(r"[a-z0-9]+", _normalize_user_input(value)) if len(token) > 1}


def _parse_decimal(value):
    try:
        return Decimal(str(value or "0"))
    except (InvalidOperation, ValueError):
        return Decimal("0")


def _format_currency(value):
    return f"${float(_parse_decimal(value)):,.2f}"


def _extract_order_id(text):
    match = re.search(r"(?:pedido|orden|order)\D{0,12}(\d+)", _normalize(text))
    return match.group(1) if match else None


def _is_greeting(message):
    normalized = _normalize_user_input(message)
    greetings = {
        "hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "hey", "hello", "holi"
    }
    return normalized in greetings or any(normalized.startswith(item) for item in greetings)


def _is_ambiguous_reference(message):
    normalized = _normalize_user_input(message)
    patterns = [
        "y de esos", "de esos", "y mas", "y más", "mas", "más", "y eso", "eso como es",
        "como asi", "como así", "que mas", "que más", "aja pero el ultimo", "el ultimo", "el último",
    ]
    return normalized in patterns or any(normalized.startswith(pattern) for pattern in patterns)


def _is_alternative_request(message):
    normalized = _normalize_user_input(message)
    terms = [
        "ese", "esos", "esa", "esas", "otros", "otras", "ademas de ese", "además de ese",
        "otra opcion", "otra opción", "otros modelos", "mas celulares", "más celulares",
        "que mas tienes", "que más tienes", "solo ese", "mas opciones", "más opciones",
    ]
    return any(term in normalized for term in terms)


def _is_follow_up(message, context):
    if not context.get("last_internal_topic") and not context.get("last_domain"):
        return False
    normalized = _normalize_user_input(message)
    followup_starts = ("y ", "y los", "y las", "y el", "y la", "pero", "tambien", "también")
    return normalized.startswith(followup_starts) or _is_ambiguous_reference(message) or len(_tokens(message)) <= 4


def _is_out_of_scope(message):
    normalized = _normalize_user_input(message)
    terms = [
        "clima", "weather", "temperatura", "lluvia", "pronostico", "pronóstico",
        "trafico", "tráfico", "noticias", "hora actual", "partido", "politica publica",
    ]
    return any(term in normalized for term in terms)


def _domain_group(intent, topic, domain=None):
    if domain:
        return domain
    if intent in {"PEDIDO_MONTO", "PEDIDO_ESTADO"} or topic in {"order_amount", "order_status"}:
        return "orders"
    if intent == "POLITICAS" or topic == "policies":
        return "policies"
    if intent == "PRODUCTOS" or topic in {"promotions", "stock", "products"}:
        return "catalog"
    return "general"


def _detect_topic_change(message, raw_intent, entities, context):
    last_topic = context.get("last_internal_topic")
    if not last_topic and not context.get("last_domain"):
        return False
    if _is_greeting(message):
        return True
    if _is_out_of_scope(message):
        return True
    current_group = _domain_group(raw_intent, None)
    previous_group = _domain_group(context.get("last_intent"), last_topic, context.get("last_domain"))
    explicit_topic = _has_explicit_current_topic(message)
    if explicit_topic and current_group != "general" and previous_group != current_group:
        return True
    if raw_intent == "FAQ" and not _is_follow_up(message, context) and len(_tokens(message)) >= 4:
        return True
    if explicit_topic and previous_group == "catalog" and current_group == "catalog":
        last_entities = context.get("last_entities") or {}
        if entities.get("brands") and last_entities.get("brands"):
            if entities["brands"][0].get("brand_id") != last_entities["brands"][0].get("brand_id"):
                return True
        if entities.get("categories") and last_entities.get("categories"):
            if entities["categories"][0].get("category_id") != last_entities["categories"][0].get("category_id"):
                return True
    return False


def _policy_bucket(text):
    normalized = _normalize_user_input(text)
    has_returns = any(term in normalized for term in ["devol", "refund", "reembolso", "cambio", "cancel", "return"])
    has_warranty = any(term in normalized for term in ["garant", "warranty", "falla", "defect"])
    has_shipping = any(term in normalized for term in ["envio", "envios", "shipping", "entrega", "tracking", "direccion", "factura"])
    has_general = any(term in normalized for term in ["politica", "politicas", "condicion", "condiciones"])
    specific_count = sum([has_returns, has_warranty, has_shipping])
    if specific_count > 1 or (has_general and specific_count == 0):
        return "general"
    if has_returns:
        return "returns"
    if has_warranty:
        return "warranty"
    if has_shipping:
        return "shipping"
    return None


def _looks_like_promotion_query(query):
    normalized = _normalize_user_input(query)
    return any(term in normalized for term in ["descuento", "descuentos", "promocion", "promociones", "promo", "oferta", "ofertas"])


def _looks_like_stock_query(query):
    normalized = _normalize_user_input(query)
    return any(term in normalized for term in ["stock", "stocks", "disponible", "disponibilidad", "inventario", "hay"])


def _has_explicit_current_topic(message):
    normalized = _normalize_user_input(message)
    topic_terms = [
        "pedido", "orden", "mi pedido", "tracking", "guia", "rastreo",
        "descuento", "descuentos", "promocion", "promociones", "promo", "oferta", "ofertas",
        "stock", "disponible", "disponibilidad", "inventario",
        "politica", "politicas", "condicion", "condiciones", "garantia", "garantias", "devolucion", "devoluciones",
        "producto", "productos", "precio", "catalogo", "marca", "ropa", "calzado", "celular", "televisor", "laptop",
        "vende", "vendes", "tienes", "barato", "economico", "muestrame",
    ]
    return any(term in normalized for term in topic_terms)


def _looks_like_order_followup(message, context):
    normalized = _normalize_user_input(message)
    if context.get("last_domain") != "pedidos" and context.get("last_order_query_type") is None:
        return False
    terms = [
        "pedido", "pedidos", "ultimo", "último", "mas pedidos", "más pedidos", "historial",
        "cancelado", "cancelados", "devuelto", "devueltos", "entregado", "entregados",
        "el total", "el monto", "detalle", "ese pedido", "ese", "otros",
    ]
    return any(term in normalized for term in terms)


def _looks_like_order_request(message):
    normalized = _normalize_user_input(message)
    terms = [
        "pedido", "pedidos", "orden", "ordenes", "órdenes", "historial", "ultimo", "último",
        "cancelado", "cancelados", "devuelto", "devueltos", "entregado", "entregados",
        "monto", "total", "detalle", "mis compras", "mis pedidos",
    ]
    return any(term in normalized for term in terms)


def _merge_with_context(message, context, entities):
    if not _is_follow_up(message, context):
        return message
    if _has_explicit_current_topic(message):
        return message

    prefix_map = {
        "promociones": "promociones",
        "stock": "stock",
        "productos": "productos",
        "politicas": "politicas",
        "pedidos": "pedido",
    }
    effective = message
    prefix = prefix_map.get(context.get("active_domain") or context.get("last_domain"))
    normalized = _normalize_user_input(effective)
    if prefix and prefix not in normalized:
        effective = f"{prefix} {effective}"

    has_current_entities = any(entities.get(key) for key in ["categories", "brands", "products"])
    last_entities = context.get("last_entities") or {}
    active_brand = context.get("active_brand")
    active_category = context.get("active_category")
    active_subtype = context.get("active_subtype")
    active_product_reference = context.get("active_product_reference") or {}
    anchor = context.get("reference_anchor") or {}
    allow_product_context = context.get("last_result_type") in {"producto_especifico", "stock_product"}
    if not has_current_entities:
        if active_brand:
            effective = f"{effective} {active_brand}"
        elif last_entities.get("brands"):
            effective = f"{effective} {last_entities['brands'][0]['name']}"
        if active_category and active_category not in _normalize_user_input(effective):
            effective = f"{effective} {active_category}"
        elif last_entities.get("categories"):
            effective = f"{effective} {last_entities['categories'][0]['name']}"
        if active_subtype and active_subtype not in _normalize_user_input(effective):
            effective = f"{effective} {active_subtype}"
        elif last_entities.get("subtypes"):
            effective = f"{effective} {last_entities['subtypes'][0]['name']}"
        elif active_product_reference.get("name") and allow_product_context and not _is_alternative_request(message):
            effective = f"{effective} {active_product_reference['name']}"
        elif anchor.get("name") and allow_product_context and not _is_alternative_request(message):
            effective = f"{effective} {anchor['name']}"
        elif last_entities.get("products") and allow_product_context and not _is_ambiguous_reference(message):
            effective = f"{effective} {last_entities['products'][0]['name']}"
    return effective


def _followup_context_entities(fresh_entities, context):
    last_entities = context.get("last_entities") or {}
    context_entities = {}
    if not fresh_entities.get("brands") and context.get("active_brand"):
        matching_brands = [item for item in last_entities.get("brands", []) if item.get("name") == context.get("active_brand")]
        if matching_brands:
            context_entities["brands"] = matching_brands
    elif not fresh_entities.get("brands") and not fresh_entities.get("products") and last_entities.get("brands"):
        context_entities["brands"] = list(last_entities.get("brands", []))
    if not any(fresh_entities.get(key) for key in ["categories", "subtypes", "products"]) and context.get("active_category"):
        active_category = context.get("active_category")
        if last_entities.get("categories"):
            matching = [item for item in last_entities.get("categories", []) if item.get("name") == active_category]
            context_entities["categories"] = matching or list(last_entities.get("categories", []))
    elif not any(fresh_entities.get(key) for key in ["categories", "subtypes", "products"]) and last_entities.get("categories"):
        context_entities["categories"] = list(last_entities.get("categories", []))
    if not any(fresh_entities.get(key) for key in ["subtypes", "products"]) and context.get("active_subtype"):
        context_entities["subtypes"] = [{"name": context.get("active_subtype")}]
    elif not any(fresh_entities.get(key) for key in ["subtypes", "products"]) and last_entities.get("subtypes"):
        context_entities["subtypes"] = list(last_entities.get("subtypes", []))
    allow_product_context = context.get("last_result_type") in {"producto_especifico", "stock_product"}
    if (
        allow_product_context
        and not any(fresh_entities.get(key) for key in ["brands", "categories", "products", "subtypes"])
        and (context.get("active_product_reference") or last_entities.get("products"))
    ):
        active_product_reference = context.get("active_product_reference") or {}
        if active_product_reference.get("product_id"):
            context_entities["products"] = [active_product_reference]
        else:
            context_entities["products"] = list(last_entities.get("products", []))
    return context_entities


def _resolve_followup_with_memory(message, context, raw_intent, fresh_entities):
    follow_up = _is_follow_up(message, context)
    if not follow_up:
        return {
            "raw_intent": raw_intent,
            "follow_up": False,
            "use_context_entities": False,
            "use_context_message": False,
        }

    last_domain = context.get("active_domain") or context.get("last_domain")
    normalized = _normalize_user_input(message)
    resolved_intent = raw_intent
    if raw_intent == "FAQ":
        if last_domain == "pedidos" and (_looks_like_order_followup(message, context) or any(term in normalized for term in ["ultimo", "último", "cancelado", "entregado", "historial", "pedido", "pedidos", "total", "monto"])):
            resolved_intent = "PEDIDO_MONTO" if any(term in normalized for term in ["monto", "total", "subtotal", "impuestos"]) else "PEDIDO_ESTADO"
        elif last_domain in {"productos", "promociones", "stock"}:
            resolved_intent = "PRODUCTOS"
        elif last_domain == "politicas":
            resolved_intent = "POLITICAS"

    use_context_entities = resolved_intent in {"FAQ", "PRODUCTOS", "POLITICAS"} and last_domain in {"productos", "promociones", "stock", "politicas"}
    use_context_message = resolved_intent in {"FAQ", "PRODUCTOS", "POLITICAS"} and not _has_explicit_current_topic(message)
    if last_domain == "pedidos":
        use_context_entities = False
        use_context_message = False
    if any(fresh_entities.get(key) for key in ["brands", "categories", "products", "subtypes"]):
        use_context_message = False
    if _is_general_catalog_query(message, fresh_entities) or _is_budget_query(message) or _is_general_stock_query(message, fresh_entities):
        use_context_entities = False
        use_context_message = False
    if _is_ambiguous_reference(message) and last_domain in {"productos", "promociones", "stock"}:
        use_context_entities = True
        use_context_message = True
    return {
        "raw_intent": resolved_intent,
        "follow_up": True,
        "use_context_entities": use_context_entities,
        "use_context_message": use_context_message,
    }


def _wants_multiple_options(query):
    normalized = _normalize_user_input(query)
    return any(term in normalized for term in ["otros modelos", "otros productos", "que otros", "qué otros", "mas opciones", "más opciones"])


def _is_general_stock_query(query, entities):
    normalized = _normalize_user_input(query)
    broad_terms = [
        "que stock", "que stocks", "que tienen disponible", "que tienen disponibles",
        "que hay disponible", "que hay en stock", "que hay", "stocks hay", "disponible", "disponibles",
    ]
    return not any(entities.get(key) for key in ["brands", "categories", "products", "subtypes"]) and any(term in normalized for term in broad_terms)


def _is_exact_product_mention(query, entities):
    if not entities.get("products"):
        return False
    normalized = _normalize_user_input(query)
    product_name = _normalize(entities["products"][0].get("name"))
    return bool(product_name and product_name in normalized)


def _is_general_catalog_query(query, entities):
    normalized = _normalize_user_input(query)
    broad_terms = [
        "que vendes", "que tienes", "muestrame lo que tenga", "muestreme lo que tenga",
        "muestreme", "muestrame", "quiero algo barato", "quiero algo economico",
        "quiero ver", "que manejan", "que ofrecen",
    ]
    return not any(entities.get(key) for key in ["brands", "categories", "products", "subtypes"]) and any(term in normalized for term in broad_terms)


def _is_budget_query(query):
    normalized = _normalize_user_input(query)
    return any(term in normalized for term in ["barato", "barata", "economico", "economica"])


def _prefers_list_response(query, context, entities):
    normalized = _normalize_user_input(query)
    asks_for_options = any(term in normalized for term in ["productos", "modelos", "opciones", "que tienes", "que vendes", "que hay", "muestrame", "muestreme"])
    filtered_scope = any(entities.get(key) for key in ["brands", "categories", "subtypes"]) and not _is_exact_product_mention(query, entities)
    return (
        _wants_multiple_options(query)
        or _is_general_catalog_query(query, entities)
        or _is_ambiguous_reference(query)
        or (asks_for_options and filtered_scope)
        or (context.get("last_result_type") in {"lista_productos", "stock_categoria", "stock_brand"} and not entities.get("products"))
    )


def _wants_multiple_options(query):
    normalized = _normalize_user_input(query)
    return any(term in normalized for term in ["otros modelos", "otros productos", "que otros", "mas opciones", "y mas", "de esos", "muestrame lo que tenga", "ademas de ese", "solo ese"])


def _format_stock_summary(summary):
    if not summary:
        return "Ahora mismo no encontré stock disponible en el catálogo."
    parts = ["Ahora mismo tenemos disponibilidad en estas categorías:"]
    for item in summary[:5]:
        examples = ", ".join(item.get("sample_names", [])[:2])
        example_text = f" Ejemplos: {examples}." if examples else ""
        parts.append(f"{item.get('category_name')}: {item.get('available_products')} productos con stock.{example_text}")
    parts.append("Si quieres, te muestro una categoría o marca en detalle.")
    return " ".join(parts)


def _format_catalog_overview(summary):
    if not summary:
        return "Ahora mismo no encontrÃ© productos disponibles en el catÃ¡logo."
    parts = ["Ahora mismo tenemos opciones en estas categorÃ­as:"]
    for item in summary[:5]:
        examples = ", ".join(item.get("sample_names", [])[:2])
        example_text = f" Ejemplos: {examples}." if examples else ""
        parts.append(f"{item.get('category_name')}: {item.get('available_products')} opciones.{example_text}")
    parts.append("Si quieres, te muestro una categorÃ­a, una marca o algunas opciones econÃ³micas.")
    return " ".join(parts)


def _format_product_item(product):
    shipping = f'{product.get("shipping_days") or "N/A"} dias'
    return_days = product.get("return_days") or "0"
    return (
        f'{product.get("name")}. '
        f'Precio: {_format_currency(product.get("price"))}. '
        f'Garantia: {product.get("warranty_months") or "0"} meses. '
        f'Devolucion: {return_days} dias. '
        f'Envio estimado: {shipping}. '
        f'{product.get("description", "").strip()}'
    ).strip()


def _format_product_list(products, subtype=None, brand_name=None, category_name=None):
    names = ", ".join(product.get("name") for product in products[:5])
    if subtype:
        return f"Estos son algunos modelos disponibles de {subtype}: {names}."
    if brand_name and category_name:
        return f"Estas son algunas opciones de {brand_name} en {category_name}: {names}."
    if brand_name:
        return f"Estas son algunas opciones de {brand_name}: {names}."
    if category_name:
        return f"Estos son algunos modelos disponibles en {category_name}: {names}."
    return f"Estos son algunos modelos disponibles: {names}."


def _active_catalog_filters(entities, context):
    active_product = context.get("active_product_reference") or {}
    reference_anchor = context.get("reference_anchor") or {}
    last_entities = context.get("last_entities") or {}
    active_brand_name = entities.get("brands", [{}])[0].get("name") if entities.get("brands") else context.get("active_brand")
    active_category_name = entities.get("categories", [{}])[0].get("name") if entities.get("categories") else context.get("active_category")
    last_brand = next((item for item in last_entities.get("brands", []) if item.get("name") == active_brand_name), {})
    last_category = next((item for item in last_entities.get("categories", []) if item.get("name") == active_category_name), {})
    return {
        "subtype": entities.get("subtypes", [{}])[0].get("name") if entities.get("subtypes") else context.get("active_subtype"),
        "brand_id": entities.get("brands", [{}])[0].get("brand_id") if entities.get("brands") else (active_product.get("brand_id") or reference_anchor.get("brand_id") or last_brand.get("brand_id")),
        "brand_name": active_brand_name,
        "category_id": entities.get("categories", [{}])[0].get("category_id") if entities.get("categories") else (active_product.get("category_id") or reference_anchor.get("category_id") or last_category.get("category_id")),
        "category_name": active_category_name,
        "product_id": entities.get("products", [{}])[0].get("product_id") if entities.get("products") else (active_product.get("product_id") or reference_anchor.get("product_id")),
    }


def _resolve_product_alternatives(query, entities, context, limit=5):
    filters = _active_catalog_filters(entities, context)
    subtype = filters["subtype"]
    product_id = filters["product_id"]
    strict_brand_scope = bool(filters["brand_id"] and (context.get("active_brand") or entities.get("brands")))
    if product_id:
        if strict_brand_scope:
            products = obtener_productos_relacionados_misma_marca(
                filters["brand_id"],
                exclude_product_id=product_id,
                category_id=filters["category_id"],
                subtype=subtype,
                limit=limit,
            )
        else:
            products = obtener_alternativas_al_producto_actual(
                product_id,
                limit=limit,
                brand_id=filters["brand_id"],
                category_id=filters["category_id"],
                subtype=subtype,
            )
    elif filters["brand_id"]:
        products = obtener_productos_relacionados_misma_marca(
            filters["brand_id"],
            category_id=filters["category_id"],
            subtype=subtype,
            limit=limit,
        )
    elif filters["category_id"]:
        products = obtener_productos_relacionados_misma_categoria(
            filters["category_id"],
            subtype=subtype,
            limit=limit,
        )
    else:
        products = buscar_productos_catalogo(query, subtype=subtype, limit=limit)
    if not products:
        return {"products": [], "text": "", "scope": "lista_misma_marca" if strict_brand_scope else ("lista_misma_categoria" if filters["category_id"] or subtype else "lista_productos")}
    if "solo ese" in _normalize_user_input(query):
        if strict_brand_scope:
            text = f"No, tambien tengo estas opciones de {filters['brand_name']}: {', '.join(product.get('name') for product in products[:5])}."
        else:
            text = f"No, tambien tengo estas opciones: {', '.join(product.get('name') for product in products[:5])}."
    else:
        text = _format_product_list(products, subtype=subtype, brand_name=filters["brand_name"], category_name=filters["category_name"])
    return {
        "products": products,
        "text": text,
        "scope": "lista_misma_marca" if strict_brand_scope else ("lista_misma_categoria" if filters["category_id"] or subtype else "lista_productos"),
    }


def _search_products(query, entities, context, prefer_multiple=False):
    subtype = entities.get("subtypes", [{}])[0].get("name") if entities.get("subtypes") else None
    brand_id = entities.get("brands", [{}])[0].get("brand_id") if entities.get("brands") else None
    brand_name = entities.get("brands", [{}])[0].get("name") if entities.get("brands") else None
    category_id = entities.get("categories", [{}])[0].get("category_id") if entities.get("categories") else None
    category_name = entities.get("categories", [{}])[0].get("name") if entities.get("categories") else None
    limit = 5 if prefer_multiple else 3
    if _is_alternative_request(query):
        alternative_result = _resolve_product_alternatives(query, entities, context, limit=limit)
        if alternative_result["products"]:
            return alternative_result
        if context.get("active_product_reference") or context.get("active_category") or context.get("active_subtype"):
            anchor = context.get("reference_anchor") or context.get("active_product_reference") or {}
            anchor_name = anchor.get("name") or context.get("active_subtype") or context.get("active_category") or "esa familia"
            return {
                "products": [],
                "text": f"Por ahora no encontrÃ© mÃ¡s opciones claras dentro de {anchor_name}. Si quieres, revisamos otra marca o una familia cercana.",
                "scope": "lista_misma_categoria",
            }
    products = (
        obtener_productos_economicos(limit=limit, brand_id=brand_id, category_id=category_id, subtype=subtype)
        if _is_budget_query(query)
        else buscar_productos_catalogo(query, brand_id=brand_id, category_id=category_id, subtype=subtype, limit=limit)
    )
    if not products:
        return {"products": [], "text": "", "scope": ""}
    if prefer_multiple or "otros modelos" in _normalize_user_input(query) or "otros productos" in _normalize_user_input(query):
        text = _format_product_list(products, subtype=subtype, brand_name=brand_name, category_name=category_name)
        if _is_budget_query(query):
            text = f"Estas son algunas opciones econÃ³micas que encontrÃ©: {', '.join(product.get('name') for product in products[:5])}."
        return {"products": products, "text": text, "scope": "lista_misma_categoria" if category_id or subtype else "lista_productos"}
    return {"products": products[:1], "text": _format_product_item(products[0]), "scope": "producto_especifico"}


def _format_promotions(promotions):
    if not promotions:
        return "No encontre promociones activas para esa consulta."
    parts = []
    for promo in promotions[:5]:
        minimum = promo.get("min_purchase_amount") or "0"
        minimum_text = f" Compra minima: {_format_currency(minimum)}." if minimum not in {"", "0", "0.0"} else ""
        parts.append(
            f"{promo.get('promotion_name')}: {promo.get('description')} Vigencia: {promo.get('start_date')} a {promo.get('end_date')}.{minimum_text}"
        )
    return " ".join(parts)


def _format_stock(entries, title=None):
    if not entries:
        return "No encontré stock disponible para esa consulta."
    parts = [f"{title}." if title else ""]
    for item in entries[:5]:
        parts.append(f"{item.get('name')}: {item.get('available_stock')} unidades disponibles.")
    parts.append("Si quieres, te muestro más opciones o revisamos otra categoría.")
    return " ".join(part for part in parts if part)


def _stock_products_snapshot(entries):
    result = []
    for item in (entries or [])[:5]:
        result.append(
            {
                "product_id": item.get("product_id"),
                "name": item.get("name") or item.get("product", {}).get("name"),
                "brand_id": item.get("brand_id") or item.get("product", {}).get("brand_id"),
                "category_id": item.get("category_id") or item.get("product", {}).get("category_id"),
            }
        )
    return result


def _order_status_label(status):
    normalized = _normalize(status)
    mapping = {
        "cancelled": "cancelado",
        "returned": "devuelto",
        "delivered": "entregado",
        "shipped": "enviado",
        "pending": "pendiente",
        "payment_confirmed": "pago confirmado",
        "preparing": "en preparación",
    }
    return mapping.get(normalized, status)


def _resolve_order_query_type(query, intent, context):
    normalized = _normalize(query)
    if any(term in normalized for term in ["cuantos pedidos", "cuantos tengo", "cuantos hay", "cantidad de pedidos"]):
        return "ORDER_COUNT", None
    if any(term in normalized for term in ["tengo mas pedidos", "tengo otros pedidos", "hay otros", "aparte de ese hay mas", "hay mas"]):
        return "ORDER_HAS_MORE", None
    if any(term in normalized for term in ["solo ese", "ese es el unico", "es el unico"]):
        return "ORDER_ONLY_ONE", None
    if any(term in normalized for term in ["historial", "mis pedidos", "mas pedidos", "más pedidos", "otros pedidos", "listar pedidos", "lista de pedidos"]):
        return "ORDER_HISTORY", None
    if any(term in normalized for term in ["cancelado", "cancelados", "cancelada", "canceladas"]):
        return "ORDER_FILTERED_STATUS", "cancelled"
    if any(term in normalized for term in ["devuelto", "devueltos", "devolucion", "devoluciones", "retornado", "retornados"]):
        return "ORDER_FILTERED_STATUS", "returned"
    if any(term in normalized for term in ["entregado", "entregados", "entrega", "entregas"]):
        return "ORDER_FILTERED_STATUS", "delivered"
    if any(term in normalized for term in ["enviado", "enviados", "despachado", "despachados"]):
        return "ORDER_FILTERED_STATUS", "shipped"
    if any(term in normalized for term in ["ultimo", "último", "mas reciente", "más reciente"]):
        if any(term in normalized for term in ["monto", "total", "cuanto", "cuánto", "valor"]):
            return "ORDER_SINGLE_AMOUNT", None
        return "ORDER_LAST", None
    if any(term in normalized for term in ["detalle", "detalles", "que trae", "que incluye", "qué incluye", "que tenia", "qué tenía"]):
        return "ORDER_SINGLE_DETAIL", None
    if intent == "PEDIDO_MONTO" or any(term in normalized for term in ["monto", "total", "subtotal", "impuestos", "cuanto pague", "cuánto pagué"]):
        return "ORDER_SINGLE_AMOUNT", None
    if _extract_order_id(query):
        return "ORDER_SINGLE_STATUS", None
    if any(term in normalized for term in ["ese pedido", "ese", "el pedido", "mi pedido"]):
        return "ORDER_SINGLE_STATUS", None
    if any(term in normalized for term in ["pedidos", "ordenes", "órdenes"]) and not any(term in normalized for term in ["mi pedido", "el pedido"]):
        return "ORDER_HISTORY", None
    previous_type = context.get("last_order_query_type")
    if previous_type in {"ORDER_HISTORY", "ORDER_FILTERED_STATUS", "ORDER_LAST"} and any(term in normalized for term in ["y el total", "y el monto", "el total", "el monto"]):
        return "ORDER_SINGLE_AMOUNT", None
    return "ORDER_SINGLE_STATUS", None


def _select_order_from_context(pedidos, query, context, query_type, status_filter=None):
    requested_order_id = _extract_order_id(query)
    if requested_order_id:
        return next((row for row in pedidos if row.get("order_id") == requested_order_id), None)
    if status_filter and context.get("last_order_id"):
        contextual = next((row for row in pedidos if row.get("order_id") == str(context.get("last_order_id"))), None)
        if contextual and _normalize(contextual.get("status")) == status_filter:
            return contextual
    if query_type in {"ORDER_SINGLE_STATUS", "ORDER_SINGLE_AMOUNT", "ORDER_SINGLE_DETAIL"} and context.get("last_order_id"):
        contextual = next((row for row in pedidos if row.get("order_id") == str(context.get("last_order_id"))), None)
        if contextual:
            return contextual
    ultimo = obtener_ultimo_pedido_cliente(context.get("authenticated_customer_id") or "")
    if ultimo:
        return next((row for row in pedidos if row.get("order_id") == ultimo.get("order_id")), ultimo)
    return pedidos[0] if pedidos else None


def _format_order_status_response(order_id):
    estado = obtener_estado_pedido(order_id)
    order = estado.get("order", {})
    shipment = estado.get("shipment", {})
    latest_tracking = estado.get("latest_tracking", {})
    parts = [
        f"Pedido {order.get('order_id')}: estado {_order_status_label(order.get('status'))}.",
        f"Fecha: {order.get('order_date')}.",
    ]
    if shipment:
        parts.append(f"Envío: {_order_status_label(shipment.get('shipment_status') or '')} con {shipment.get('carrier')}.")
        if shipment.get("tracking_number"):
            parts.append(f"Guía: {shipment.get('tracking_number')}.")
        if shipment.get("estimated_delivery_date"):
            parts.append(f"Entrega estimada: {shipment.get('estimated_delivery_date')}.")
    elif latest_tracking:
        parts.append(f"Último tracking: {_order_status_label(latest_tracking.get('status') or '')} ({latest_tracking.get('timestamp')}).")
    parts.append("Si quieres, también puedo mostrarte el monto o el detalle de este pedido.")
    return " ".join(parts)


def _format_order_amount_response(order_id):
    detalle = obtener_detalle_pedido(order_id)
    order = detalle.get("order", {})
    return (
        f"Pedido {order.get('order_id')}. "
        f"Subtotal: {_format_currency(order.get('subtotal'))}. "
        f"Envío: {_format_currency(order.get('shipping_cost'))}. "
        f"Impuestos: {_format_currency(order.get('tax'))}. "
        f"Total: {_format_currency(order.get('total_amount'))}. "
        "Si quieres, también puedo mostrarte el estado o el detalle."
    )


def _format_order_detail_response(order_id):
    detalle = obtener_detalle_pedido(order_id)
    order = detalle.get("order", {})
    items = detalle.get("items", [])[:3]
    item_names = [item.get("product", {}).get("name") for item in items if item.get("product", {}).get("name")]
    parts = [
        f"Pedido {order.get('order_id')}: estado {_order_status_label(order.get('status'))}.",
        f"Total: {_format_currency(order.get('total_amount'))}.",
    ]
    if item_names:
        parts.append(f"Productos: {', '.join(item_names)}.")
    parts.append("Si quieres, también puedo mostrarte el estado o el total de este pedido.")
    return " ".join(parts)


def _format_order_history_response(resumenes, total_count, status_filter=None):
    if not resumenes:
        if status_filter:
            return f"Revisé tus pedidos y no encontré ninguno con estado {_order_status_label(status_filter)}. Si quieres, puedo revisar otro estado o mostrarte tu historial completo."
        return "Revisé tu cuenta y por ahora no veo pedidos registrados. Si quieres, puedo ayudarte a revisar otra cosa de tu cuenta."
    parts = [f"Te resumo lo que encontré: {total_count} pedido(s)."]
    for item in resumenes[:5]:
        parts.append(
            f"Pedido {item.get('order_id')}: {_order_status_label(item.get('status'))}, "
            f"fecha {item.get('order_date')}, total {_format_currency(item.get('total_amount'))}."
        )
    parts.append("Si quieres, te muestro el detalle o el monto de alguno.")
    return " ".join(parts)


def _format_order_count_response(total_count):
    if total_count <= 0:
        return "Por ahora no tienes pedidos registrados. Si quieres, puedo ayudarte con otra consulta."
    if total_count == 1:
        return "Tienes 1 pedido registrado en este momento."
    return f"Tienes {total_count} pedidos registrados en este momento."


def _format_order_has_more_response(total_count, current_order_id=None):
    if total_count <= 0:
        return "Por ahora no veo pedidos registrados en tu cuenta."
    if total_count == 1:
        return "Por ahora solo tienes un pedido registrado, asi que ese es el unico."
    extra_count = total_count - 1 if current_order_id else total_count
    if extra_count <= 0:
        return "Por ahora solo aparece ese pedido en tu cuenta."
    return f"Si, ademas de ese tienes otros {extra_count} pedidos registrados."


def _format_order_only_one_response(total_count):
    if total_count <= 0:
        return "Por ahora no veo pedidos registrados en tu cuenta."
    if total_count == 1:
        return "Por ahora solo tienes un pedido registrado, asi que ese es el unico."
    return f"No, tienes {total_count} pedidos registrados en total."


def _clean_policy_text(text):
    cleaned = re.sub(r"[*_#>`-]+", " ", str(text or ""))
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    sentences = re.split(r"(?<=[.!?])\s+", cleaned)
    return " ".join(sentence.strip() for sentence in sentences[:2] if sentence.strip())[:220]


def _handle_order_query(customer_id, intent, query, context):
    pedidos = obtener_pedidos_por_cliente(customer_id)
    if not pedidos:
        return {
            "text": "Revisé tu cuenta y por ahora no veo pedidos registrados. Si quieres, puedo ayudarte con otra consulta.",
            "query_type": "ORDER_HISTORY",
            "last_order_id": None,
            "last_order_list": [],
            "response_kind": "order_history",
        }

    pedidos.sort(key=lambda row: row.get("order_date") or "", reverse=True)
    query_type, status_filter = _resolve_order_query_type(query, intent, context)

    if query_type == "ORDER_COUNT":
        return {
            "text": _format_order_count_response(len(pedidos)),
            "query_type": query_type,
            "last_order_id": context.get("last_order_id") or pedidos[0].get("order_id"),
            "last_order_list": [row.get("order_id") for row in pedidos[:5]],
            "response_kind": "order_count",
        }

    if query_type == "ORDER_HAS_MORE":
        current_order_id = context.get("last_order_id") or pedidos[0].get("order_id")
        return {
            "text": _format_order_has_more_response(len(pedidos), current_order_id=current_order_id),
            "query_type": query_type,
            "last_order_id": current_order_id,
            "last_order_list": [row.get("order_id") for row in pedidos[:5]],
            "response_kind": "order_count",
        }

    if query_type == "ORDER_ONLY_ONE":
        current_order_id = context.get("last_order_id") or pedidos[0].get("order_id")
        return {
            "text": _format_order_only_one_response(len(pedidos)),
            "query_type": query_type,
            "last_order_id": current_order_id,
            "last_order_list": [row.get("order_id") for row in pedidos[:5]],
            "response_kind": "order_count",
        }

    if query_type == "ORDER_LAST":
        pedido = pedidos[0]
        return {
            "text": _format_order_status_response(pedido.get("order_id")),
            "query_type": query_type,
            "last_order_id": pedido.get("order_id"),
            "last_order_list": [pedido.get("order_id")],
            "response_kind": "order_last",
        }

    if query_type == "ORDER_HISTORY":
        resumenes = resumir_pedidos(pedidos, limit=5)
        return {
            "text": _format_order_history_response(resumenes, len(pedidos)),
            "query_type": query_type,
            "last_order_id": pedidos[0].get("order_id"),
            "last_order_list": [row.get("order_id") for row in pedidos[:5]],
            "response_kind": "order_history",
        }

    if query_type == "ORDER_FILTERED_STATUS":
        filtrados = filtrar_pedidos_por_estado(customer_id, status_filter)
        resumenes = resumir_pedidos(filtrados, limit=5)
        return {
            "text": _format_order_history_response(resumenes, len(filtrados), status_filter=status_filter),
            "query_type": query_type,
            "last_order_id": filtrados[0].get("order_id") if filtrados else None,
            "last_order_list": [row.get("order_id") for row in filtrados[:5]],
            "response_kind": "order_history",
        }

    pedido = _select_order_from_context(pedidos, query, context, query_type, status_filter=status_filter)
    if not pedido:
        return {
            "text": "No encontré información para ese pedido.",
            "query_type": query_type,
            "last_order_id": None,
            "last_order_list": [],
            "response_kind": "order_status",
        }

    order_id = pedido.get("order_id")
    if query_type == "ORDER_SINGLE_AMOUNT":
        text = _format_order_amount_response(order_id)
        response_kind = "order_amount"
    elif query_type == "ORDER_SINGLE_DETAIL":
        text = _format_order_detail_response(order_id)
        response_kind = "order_detail"
    else:
        text = _format_order_status_response(order_id)
        response_kind = "order_status"
    return {
        "text": text,
        "query_type": query_type,
        "last_order_id": order_id,
        "last_order_list": [row.get("order_id") for row in pedidos[:5]],
        "response_kind": response_kind,
    }


def _format_policy_response(matches):
    if not matches:
        return ""
    buckets = {item.get("bucket") for item in matches if item.get("bucket")}
    if len(buckets) > 1:
        mapping = {
            "returns": "Devoluciones y cambios",
            "warranty": "Garantia",
            "shipping": "Envios",
        }
        parts = []
        used = set()
        for match in matches:
            bucket = match.get("bucket") or match.get("document")
            if bucket in used:
                continue
            used.add(bucket)
            label = mapping.get(bucket, match.get("title"))
            snippet = _clean_policy_text(match.get("content"))
            if snippet:
                parts.append(f"{label}: {snippet}")
        return "\n\n".join(parts[:3])
    parts = []
    for match in matches[:3]:
        snippet = _clean_policy_text(match.get("content"))
        if snippet:
            parts.append(f'{match["title"]}: {snippet}')
    return "\n\n".join(parts)


def _policy_response_kind(message, matches):
    bucket = _policy_bucket(message)
    if bucket == "general" or len({item.get("document") for item in matches}) > 1:
        return "policy_general"
    if bucket == "returns":
        return "policy_returns"
    if bucket == "warranty":
        return "policy_warranty"
    if bucket == "shipping":
        return "policy_shipping"
    return "policy_specific"


def _recent_context(context):
    return list(context.get("recent_turns") or [])[-3:]


def _auth_prompt_for_missing(dni, phone):
    if dni and not phone:
        return "Ya tengo tu dni. Ahora compárteme tu phone para continuar."
    if phone and not dni:
        return "Ya tengo tu phone. Ahora compárteme tu dni para continuar."
    return "Necesito autenticacion para consultar pedidos. Comparte tu dni y phone para continuar."


def _last_non_auth_user_query(context):
    for turn in reversed(context.get("recent_turns") or []):
        user_message = str(turn.get("user") or "").strip()
        auth_fields = extract_auth_fields(user_message, loose=True)
        if user_message and not auth_fields.get("dni") and not auth_fields.get("phone"):
            return user_message
    return ""


def _entity_snapshot(entities):
    snapshot = {}
    if entities.get("categories"):
        snapshot["categories"] = [item.get("name") for item in entities["categories"][:2]]
    if entities.get("brands"):
        snapshot["brands"] = [item.get("name") for item in entities["brands"][:2]]
    if entities.get("products"):
        snapshot["products"] = [item.get("name") for item in entities["products"][:2]]
    if entities.get("subtypes"):
        snapshot["subtypes"] = [item.get("name") for item in entities["subtypes"][:2]]
    return snapshot


def _shown_products_snapshot(products):
    result = []
    for item in (products or [])[:5]:
        if not item:
            continue
        result.append(
            {
                "product_id": item.get("product_id"),
                "name": item.get("name"),
                "brand_id": item.get("brand_id"),
                "category_id": item.get("category_id"),
            }
        )
    return result


def _memory_catalog_state(entities, response_kind, shown_products):
    shown_products = _shown_products_snapshot(shown_products)
    active_category = entities["categories"][0].get("name") if entities.get("categories") else None
    active_subtype = entities["subtypes"][0].get("name") if entities.get("subtypes") else None
    active_brand = entities["brands"][0].get("name") if entities.get("brands") else None
    active_product_reference = shown_products[0] if shown_products and response_kind in {"product", "stock_product"} else None
    reference_anchor = active_product_reference or (shown_products[0] if shown_products else None)
    if not reference_anchor and entities.get("subtypes"):
        reference_anchor = {"name": entities["subtypes"][0].get("name")}
    elif not reference_anchor and entities.get("categories"):
        reference_anchor = {"name": entities["categories"][0].get("name")}
    return {
        "active_domain": _derive_memory_domain("PRODUCTOS", "products" if not str(response_kind or "").startswith("stock") else "stock", response_kind),
        "active_category": active_category,
        "active_subtype": active_subtype,
        "active_brand": active_brand,
        "active_product_reference": active_product_reference,
        "active_result_scope": response_kind or ("lista_misma_categoria" if shown_products else None),
        "last_shown_products": shown_products,
        "reference_anchor": reference_anchor,
    }


def _derive_memory_domain(intent, internal_topic, response_kind):
    if intent in {"PEDIDO_MONTO", "PEDIDO_ESTADO"} or internal_topic in {"order_status", "order_amount"}:
        return "pedidos"
    if internal_topic == "stock" or str(response_kind or "").startswith("stock"):
        return "stock"
    if internal_topic == "promotions" or response_kind == "promotion":
        return "promociones"
    if intent == "PRODUCTOS" or internal_topic == "products":
        return "productos"
    if intent == "POLITICAS" or internal_topic == "policies":
        return "politicas"
    return "general"


def _derive_memory_topic(entities, internal_topic, last_order_query_type):
    if entities.get("products"):
        return entities["products"][0].get("name")
    if entities.get("subtypes"):
        return entities["subtypes"][0].get("name")
    if entities.get("brands"):
        return entities["brands"][0].get("name")
    if entities.get("categories"):
        return entities["categories"][0].get("name")
    order_topics = {
        "ORDER_HISTORY": "historial de pedidos",
        "ORDER_LAST": "ultimo pedido",
        "ORDER_FILTERED_STATUS": "estado de pedidos",
        "ORDER_SINGLE_AMOUNT": "monto del pedido",
        "ORDER_SINGLE_DETAIL": "detalle del pedido",
        "ORDER_SINGLE_STATUS": "estado del pedido",
    }
    if last_order_query_type in order_topics:
        return order_topics[last_order_query_type]
    fallback = {
        "stock": "stock",
        "products": "catalogo",
        "promotions": "promociones",
        "policies": "politicas",
        "order_status": "estado del pedido",
        "order_amount": "monto del pedido",
    }
    return fallback.get(internal_topic, internal_topic)


def _derive_memory_subintent(intent, internal_topic, response_kind, last_order_query_type):
    if last_order_query_type:
        return last_order_query_type
    if response_kind:
        return response_kind
    if intent == "POLITICAS":
        return "politica_resumen"
    if intent == "PRODUCTOS" and internal_topic == "products":
        return "producto_especifico"
    return internal_topic


def _derive_memory_result_type(response_kind, internal_topic, last_order_query_type):
    if response_kind:
        return response_kind
    if last_order_query_type == "ORDER_HISTORY":
        return "historial_pedidos"
    if last_order_query_type in {"ORDER_SINGLE_STATUS", "ORDER_LAST"}:
        return "pedido_individual"
    if last_order_query_type == "ORDER_SINGLE_AMOUNT":
        return "monto_pedido"
    if last_order_query_type == "ORDER_SINGLE_DETAIL":
        return "detalle_pedido"
    fallback = {
        "faq": "faq",
        "greeting": "faq",
        "products": "lista_productos",
        "promotions": "promociones_generales",
        "stock": "stock_categoria",
        "policies": "politica_resumen",
        "account": "faq",
    }
    return fallback.get(internal_topic)


def _build_memory_update(intent, internal_topic, entities, response_kind, response_text, last_order_query_type, shown_products=None):
    summary = _plain_summary(response_text)
    memory = {
        "last_intent": intent,
        "last_subintent": _derive_memory_subintent(intent, internal_topic, response_kind, last_order_query_type),
        "last_domain": _derive_memory_domain(intent, internal_topic, response_kind),
        "last_topic": _derive_memory_topic(entities, internal_topic, last_order_query_type),
        "last_internal_topic": internal_topic,
        "last_entities": entities,
        "last_result_type": _derive_memory_result_type(response_kind, internal_topic, last_order_query_type),
        "last_result_summary": summary,
        "active_domain": "",
        "active_category": "",
        "active_subtype": "",
        "active_brand": "",
        "active_product_reference": {},
        "active_result_scope": "",
        "last_shown_products": [],
        "reference_anchor": {},
    }
    if intent == "PRODUCTOS" or internal_topic in {"products", "stock", "promotions"}:
        memory.update(_memory_catalog_state(entities, response_kind, shown_products))
    return memory


def _plain_summary(text):
    return re.sub(r"\s+", " ", str(text or "")).strip()[:220]


def _finalize(
    message,
    response_text,
    intent,
    internal_topic,
    entities,
    context,
    response_kind="",
    secciones=None,
    pending_auth=None,
    pending_auth_dni=None,
    pending_auth_phone=None,
    authenticated_customer_id=None,
    last_order_id=None,
    last_order_list=None,
    last_order_query_type=None,
    shown_products=None,
    include_recent_context=True,
):
    memory_update = _build_memory_update(intent, internal_topic, entities, response_kind, response_text, last_order_query_type, shown_products=shown_products)
    data = {
        "respuesta_base": response_text,
        "response_kind": response_kind,
        "domain": memory_update["last_domain"],
        "topic": memory_update["last_topic"],
        "entities": _entity_snapshot(entities),
        "last_result_type": memory_update["last_result_type"],
        "last_result_summary": memory_update["last_result_summary"],
        "active_domain": memory_update.get("active_domain"),
        "active_category": memory_update.get("active_category"),
        "active_subtype": memory_update.get("active_subtype"),
        "active_brand": memory_update.get("active_brand"),
        "active_result_scope": memory_update.get("active_result_scope"),
        "recent_context": _recent_context(context) if include_recent_context else [],
    }
    if secciones:
        data["secciones"] = secciones
    final_response = generar_respuesta_final(message, intent, data) if response_text else ""
    final_response = final_response or response_text or "No encontre datos confiables para esa solicitud."
    update_session_context(
        last_intent=memory_update["last_intent"],
        last_subintent=memory_update["last_subintent"],
        last_domain=memory_update["last_domain"],
        last_topic=memory_update["last_topic"],
        last_internal_topic=memory_update["last_internal_topic"],
        last_entities=memory_update["last_entities"],
        last_result_type=memory_update["last_result_type"],
        last_result_summary=memory_update["last_result_summary"],
        active_domain=memory_update.get("active_domain"),
        active_category=memory_update.get("active_category"),
        active_subtype=memory_update.get("active_subtype"),
        active_brand=memory_update.get("active_brand"),
        active_product_reference=memory_update.get("active_product_reference"),
        active_result_scope=memory_update.get("active_result_scope"),
        last_shown_products=memory_update.get("last_shown_products"),
        reference_anchor=memory_update.get("reference_anchor"),
        pending_auth=pending_auth,
        pending_auth_dni=pending_auth_dni,
        pending_auth_phone=pending_auth_phone,
        authenticated_customer_id=authenticated_customer_id,
        last_order_id=last_order_id,
        last_order_list=last_order_list,
        last_order_query_type=last_order_query_type,
        user_message=message,
        agent_message=final_response,
    )
    return final_response


def _resolve_promotions(message, entities):
    subtype = entities.get("subtypes", [{}])[0].get("name") if entities.get("subtypes") else None
    if entities.get("brands"):
        promotions = filtrar_promociones_por_marca(entities["brands"][0]["brand_id"], subtype=subtype)
    elif entities.get("categories"):
        promotions = filtrar_promociones_por_categoria(entities["categories"][0]["category_id"], subtype=subtype)
    else:
        promotions = obtener_promociones_activas()
    return _format_promotions(promotions)


def _resolve_stock(message, entities):
    subtype = entities.get("subtypes", [{}])[0].get("name") if entities.get("subtypes") else None
    if _is_general_stock_query(message, entities):
        return {"text": _format_stock_summary(resumir_stock_disponible()), "kind": "stock_general", "products": []}
    if _is_exact_product_mention(message, entities):
        item = obtener_stock_por_producto(entities["products"][0]["product_id"])
        if item.get("product"):
            product = dict(item.get("product") or {})
            return {"text": f"{product.get('name')}: {item.get('available_stock')} unidades disponibles.", "kind": "stock_product", "products": [product]}
    if entities.get("brands"):
        items = obtener_stock_por_marca(entities["brands"][0]["brand_id"], subtype=subtype)
        return {"text": _format_stock(items, f"Stock de {entities['brands'][0]['name']}"), "kind": "stock_brand", "products": _stock_products_snapshot(items)}
    if entities.get("categories"):
        items = obtener_stock_por_categoria(entities["categories"][0]["category_id"], subtype=subtype)
        return {"text": _format_stock(items, f"Stock de {entities['categories'][0]['name']}"), "kind": "stock_category", "products": _stock_products_snapshot(items)}
    if entities.get("products"):
        item = obtener_stock_por_producto(entities["products"][0]["product_id"])
        if item.get("product"):
            product = dict(item.get("product") or {})
            return {"text": f"{product.get('name')}: {item.get('available_stock')} unidades disponibles.", "kind": "stock_product", "products": [product]}
    return {"text": "", "kind": "", "products": []}


def _resolve_policy(message, intent):
    if intent != "POLITICAS" and not _policy_bucket(message):
        return "", [], ""
    matches = recuperar_politica(message)
    return _format_policy_response(matches), matches, _policy_response_kind(message, matches)


@dataclass
class EcommerceAgent:
    streaming: bool = False

    def reset_memory(self):
        reset_session()

    def __call__(self, text):
        message = str(text or "").strip()
        control_message = _normalize_user_input(message)
        context = get_session_context()
        session = get_session_customer()

        if not message:
            return "Send a valid question."

        if _is_greeting(control_message):
            response = "Hola, puedo ayudarte con productos, promociones, stock, politicas o pedidos. Si quieres revisar un pedido, te pedire autenticacion."
            return _finalize(message, response, "FAQ", "greeting", {}, context, pending_auth=False, pending_auth_dni="", pending_auth_phone="", include_recent_context=False)

        raw_intent = route_intent(control_message)
        fresh_entities = resolver_categoria_o_marca_desde_query(control_message)
        if raw_intent == "FAQ" and any(fresh_entities.get(key) for key in ["brands", "categories", "products", "subtypes"]):
            raw_intent = "PRODUCTOS"
        if raw_intent == "FAQ" and ((session.get("customer_id") and _looks_like_order_followup(control_message, context)) or _looks_like_order_request(control_message)):
            raw_intent = "PEDIDO_MONTO" if any(term in _normalize_user_input(control_message) for term in ["monto", "total", "subtotal", "impuestos", "cuanto", "cuánto"]) else "PEDIDO_ESTADO"
        followup_state = _resolve_followup_with_memory(control_message, context, raw_intent, fresh_entities)
        raw_intent = followup_state["raw_intent"]

        topic_changed = _detect_topic_change(control_message, raw_intent, fresh_entities, context)
        follow_up = followup_state["follow_up"]
        use_context_entities = follow_up and not topic_changed and followup_state["use_context_entities"]
        use_context_message = follow_up and not topic_changed and followup_state["use_context_message"]
        entities = resolver_categoria_o_marca_desde_query(control_message, _followup_context_entities(fresh_entities, context) if use_context_entities else None)
        effective_message = _merge_with_context(control_message, context, entities) if use_context_message else control_message
        if effective_message != control_message:
            entities = resolver_categoria_o_marca_desde_query(effective_message, _followup_context_entities(fresh_entities, context))
        if _looks_like_stock_query(effective_message) and follow_up and not any(entities.get(key) for key in ["brands", "categories", "subtypes", "products"]):
            entities = dict(context.get("last_entities") or {})

        intent = route_intent(effective_message) if effective_message != control_message else raw_intent

        if _is_out_of_scope(control_message):
            response = "Puedo ayudarte con productos, promociones, stock, politicas y pedidos. Sobre ese tema no tengo informacion confiable."
            return _finalize(message, response, "FAQ", "faq", {}, context, pending_auth=False, pending_auth_dni="", pending_auth_phone="", include_recent_context=False)

        auth_fields = extract_auth_fields(message, loose=bool(context.get("pending_auth") or intent in {"PEDIDO_MONTO", "PEDIDO_ESTADO"}))
        if context.get("pending_auth") and not (topic_changed and not looks_like_auth_payload(message) and intent not in {"PEDIDO_MONTO", "PEDIDO_ESTADO"}):
            pending_dni = auth_fields["dni"] or context.get("pending_auth_dni") or ""
            pending_phone = auth_fields["phone"] or context.get("pending_auth_phone") or ""
            pending_intent = context.get("last_intent") or "PEDIDO_ESTADO"
            if pending_dni and pending_phone:
                auth_attempted, auth_response = authenticate_credentials(pending_dni, pending_phone)
                if auth_attempted and get_session_customer().get("customer_id"):
                    previous_query = _last_non_auth_user_query(context) or effective_message
                    order_result = _handle_order_query(get_session_customer()["customer_id"], pending_intent, previous_query, context)
                    response = f"{auth_response} {order_result['text']}"
                    return _finalize(
                        message,
                        response,
                        pending_intent,
                        "order_status" if pending_intent == "PEDIDO_ESTADO" else "order_amount",
                        context.get("last_entities") or {},
                        context,
                        pending_auth=False,
                        pending_auth_dni="",
                        pending_auth_phone="",
                        authenticated_customer_id=get_session_customer()["customer_id"],
                        last_order_id=order_result["last_order_id"],
                        last_order_list=order_result["last_order_list"],
                        last_order_query_type=order_result["query_type"],
                    )
                return _finalize(
                    message,
                    auth_response,
                    pending_intent,
                    context.get("last_internal_topic") or "auth",
                    context.get("last_entities") or {},
                    context,
                    pending_auth=True,
                    pending_auth_dni=pending_dni,
                    pending_auth_phone=pending_phone,
                    include_recent_context=False,
                )
            response = _auth_prompt_for_missing(pending_dni, pending_phone)
            return _finalize(
                message,
                response,
                pending_intent,
                context.get("last_internal_topic") or "auth",
                context.get("last_entities") or {},
                context,
                pending_auth=True,
                pending_auth_dni=pending_dni,
                pending_auth_phone=pending_phone,
                include_recent_context=False,
            )

        if intent in {"PEDIDO_MONTO", "PEDIDO_ESTADO"}:
            if not session.get("customer_id"):
                pending_dni = auth_fields["dni"] or ""
                pending_phone = auth_fields["phone"] or ""
                if pending_dni and pending_phone:
                    auth_attempted, auth_response = authenticate_credentials(pending_dni, pending_phone)
                    if auth_attempted and get_session_customer().get("customer_id"):
                        order_result = _handle_order_query(get_session_customer()["customer_id"], intent, effective_message, context)
                        response = f"{auth_response} {order_result['text']}"
                        return _finalize(
                            message,
                            response,
                            intent,
                            "order_status" if intent == "PEDIDO_ESTADO" else "order_amount",
                            entities,
                            context,
                            pending_auth=False,
                            pending_auth_dni="",
                            pending_auth_phone="",
                            authenticated_customer_id=get_session_customer()["customer_id"],
                            last_order_id=order_result["last_order_id"],
                            last_order_list=order_result["last_order_list"],
                            last_order_query_type=order_result["query_type"],
                            response_kind=order_result["response_kind"],
                            include_recent_context=not topic_changed,
                        )
                response = _auth_prompt_for_missing(pending_dni, pending_phone)
                order_entities = {"order_id": _extract_order_id(effective_message)} if _extract_order_id(effective_message) else {}
                return _finalize(
                    message,
                    response,
                    intent,
                    "order_status" if intent == "PEDIDO_ESTADO" else "order_amount",
                    order_entities,
                    context,
                    pending_auth=True,
                    pending_auth_dni=pending_dni,
                    pending_auth_phone=pending_phone,
                    include_recent_context=False,
                )
            order_result = _handle_order_query(session["customer_id"], intent, effective_message, context)
            return _finalize(
                message,
                order_result["text"],
                intent,
                "order_status" if intent == "PEDIDO_ESTADO" else "order_amount",
                entities,
                context,
                response_kind=order_result["response_kind"],
                authenticated_customer_id=session["customer_id"],
                last_order_id=order_result["last_order_id"],
                last_order_list=order_result["last_order_list"],
                last_order_query_type=order_result["query_type"],
                include_recent_context=not topic_changed,
            )

        if _looks_like_stock_query(effective_message) or (_is_follow_up(control_message, context) and context.get("last_internal_topic") in {"stock", "products"} and "stock" in _normalize_user_input(effective_message)):
            stock_result = _resolve_stock(effective_message, entities)
            if stock_result["text"]:
                return _finalize(
                    message,
                    stock_result["text"],
                    "PRODUCTOS",
                    "stock",
                    entities,
                    context,
                    response_kind=stock_result["kind"] or "stock",
                    shown_products=stock_result.get("products"),
                    include_recent_context=not topic_changed,
                )

        if _looks_like_promotion_query(effective_message) or (use_context_message and context.get("last_internal_topic") == "promotions"):
            response = _resolve_promotions(effective_message, entities)
            return _finalize(message, response, "PRODUCTOS", "promotions", entities, context, response_kind="promotion", include_recent_context=not topic_changed)

        if intent == "PRODUCTOS":
            if _is_general_catalog_query(effective_message, entities) and not _is_budget_query(effective_message):
                response = _format_catalog_overview(resumir_stock_disponible())
                return _finalize(message, response, "PRODUCTOS", "products", entities, context, response_kind="product_catalog", include_recent_context=not topic_changed)
            product_response = _search_products(
                effective_message,
                entities,
                context,
                prefer_multiple=_prefers_list_response(effective_message, context, entities) or (follow_up and context.get("last_internal_topic") == "products"),
            )
            if product_response.get("text"):
                return _finalize(
                    message,
                    product_response["text"],
                    "PRODUCTOS",
                    "products",
                    entities,
                    context,
                    response_kind=product_response.get("scope") or ("product_catalog" if _prefers_list_response(effective_message, context, entities) else "product"),
                    shown_products=product_response.get("products"),
                    include_recent_context=not topic_changed,
                )
            if entities.get("subtypes") and any(entities.get(key) for key in ["brands", "categories"]):
                target = entities.get("brands", entities.get("categories"))[0]["name"]
                subtype = entities["subtypes"][0]["name"]
                response = f"No encontre coincidencias claras de {subtype} para {target}. Si quieres, puedo mostrarte otras opciones cercanas dentro del catalogo."
                return _finalize(message, response, "PRODUCTOS", "products", entities, context, response_kind="product", include_recent_context=not topic_changed)

        policy_response, policy_matches, policy_kind = _resolve_policy(effective_message, intent)
        if policy_response:
            return _finalize(
                message,
                policy_response,
                "POLITICAS",
                "policies",
                entities,
                context,
                response_kind=policy_kind,
                secciones=policy_matches,
                include_recent_context=not topic_changed,
            )

        if intent == "FAQ" and (_is_follow_up(control_message, context) and not topic_changed and context.get("last_internal_topic") in {"promotions", "stock", "products"}):
            if context.get("last_internal_topic") == "promotions":
                response = _resolve_promotions(effective_message, entities)
                return _finalize(message, response, "PRODUCTOS", "promotions", entities, context, response_kind="promotion")
            if context.get("last_internal_topic") == "stock":
                stock_result = _resolve_stock(effective_message, entities)
                if stock_result["text"]:
                    return _finalize(
                        message,
                        stock_result["text"],
                        "PRODUCTOS",
                        "stock",
                        entities,
                        context,
                        response_kind=stock_result["kind"] or "stock",
                        shown_products=stock_result.get("products"),
                    )
            product_response = _search_products(effective_message, entities, context, prefer_multiple=_prefers_list_response(effective_message, context, entities))
            if product_response.get("text"):
                return _finalize(
                    message,
                    product_response["text"],
                    "PRODUCTOS",
                    "products",
                    entities,
                    context,
                    response_kind=product_response.get("scope") or ("product_catalog" if _prefers_list_response(effective_message, context, entities) else "product"),
                    shown_products=product_response.get("products"),
                )

        if session.get("customer_id") and any(term in _normalize_user_input(control_message) for term in ["sesion", "session", "cuenta", "account"]):
            response = f"Sesion activa para {session.get('display_name')}."
            return _finalize(message, response, "FAQ", "account", entities, context, include_recent_context=not topic_changed)

        response = "Hola, puedo ayudarte con promociones, stock, productos, politicas o pedidos. Si quieres revisar un pedido, te pedire dni y phone."
        return _finalize(
            message,
            response,
            "FAQ",
            "faq" if topic_changed else (context.get("last_internal_topic") or "faq"),
            {} if topic_changed else entities,
            context,
            pending_auth=False if topic_changed else None,
            pending_auth_dni="" if topic_changed else None,
            pending_auth_phone="" if topic_changed else None,
            include_recent_context=not topic_changed,
        )


def create_agent(streaming: bool = False):
    reset_session()
    return EcommerceAgent(streaming=streaming)


def _run_console_chat():
    agent = create_agent()
    print("Chat de consola listo. Escribe 'salir', 'exit' o 'quit' para terminar.")
    while True:
        user_input = input("Usuario: ").strip()
        if user_input.lower() in {"salir", "exit", "quit"}:
            print("Agente: Hasta luego.")
            break
        response = agent(user_input)
        print(f"Agente: {response if response is not None else ''}")


if __name__ == "__main__":
    _run_console_chat()
