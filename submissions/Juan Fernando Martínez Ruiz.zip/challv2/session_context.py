from threading import RLock

_LOCK = RLock()
_STATE = {
    "customer_id": None,
    "display_name": None,
    "tool_traces": [],
    "conversation": {
        "last_intent": None,
        "last_subintent": None,
        "last_domain": None,
        "last_topic": None,
        "last_internal_topic": None,
        "last_entities": {},
        "last_result_type": None,
        "last_result_summary": None,
        "active_domain": None,
        "active_category": None,
        "active_subtype": None,
        "active_brand": None,
        "active_product_reference": None,
        "active_result_scope": None,
        "last_shown_products": [],
        "reference_anchor": None,
        "pending_auth": False,
        "pending_auth_dni": "",
        "pending_auth_phone": "",
        "authenticated_customer_id": None,
        "last_order_id": None,
        "last_order_list": [],
        "last_order_query_type": None,
        "recent_turns": [],
    },
}


def add_tool_trace(tool_name, input_data, output_data):
    with _LOCK:
        _STATE["tool_traces"].append(
            {
                "tool_name": tool_name,
                "input_data": input_data,
                "output_data": output_data,
            }
        )


def set_session_customer(customer_id, display_name):
    with _LOCK:
        _STATE["customer_id"] = str(customer_id)
        _STATE["display_name"] = display_name or str(customer_id)
        _STATE["conversation"]["authenticated_customer_id"] = str(customer_id)


def reset_session():
    with _LOCK:
        _STATE["customer_id"] = None
        _STATE["display_name"] = None
        _STATE["tool_traces"] = []
        _STATE["conversation"] = {
            "last_intent": None,
            "last_subintent": None,
            "last_domain": None,
            "last_topic": None,
            "last_internal_topic": None,
            "last_entities": {},
            "last_result_type": None,
            "last_result_summary": None,
            "active_domain": None,
            "active_category": None,
            "active_subtype": None,
            "active_brand": None,
            "active_product_reference": None,
            "active_result_scope": None,
            "last_shown_products": [],
            "reference_anchor": None,
            "pending_auth": False,
            "pending_auth_dni": "",
            "pending_auth_phone": "",
            "authenticated_customer_id": None,
            "last_order_id": None,
            "last_order_list": [],
            "last_order_query_type": None,
            "recent_turns": [],
        }


def get_tool_trace():
    with _LOCK:
        return list(_STATE["tool_traces"])


def get_tool_trace_length():
    with _LOCK:
        return len(_STATE["tool_traces"])


def get_tool_trace_since(index):
    with _LOCK:
        return list(_STATE["tool_traces"][int(index):])


def get_session_customer():
    with _LOCK:
        return {
            "customer_id": _STATE["customer_id"],
            "display_name": _STATE["display_name"],
        }


def get_session_context():
    with _LOCK:
        conversation = _STATE["conversation"]
        return {
            "last_intent": conversation["last_intent"],
            "last_subintent": conversation["last_subintent"],
            "last_domain": conversation["last_domain"],
            "last_topic": conversation["last_topic"],
            "last_internal_topic": conversation["last_internal_topic"],
            "last_entities": dict(conversation["last_entities"]),
            "last_result_type": conversation["last_result_type"],
            "last_result_summary": conversation["last_result_summary"],
            "active_domain": conversation["active_domain"],
            "active_category": conversation["active_category"],
            "active_subtype": conversation["active_subtype"],
            "active_brand": conversation["active_brand"],
            "active_product_reference": dict(conversation["active_product_reference"]) if conversation["active_product_reference"] else None,
            "active_result_scope": conversation["active_result_scope"],
            "last_shown_products": list(conversation["last_shown_products"]),
            "reference_anchor": dict(conversation["reference_anchor"]) if conversation["reference_anchor"] else None,
            "pending_auth": conversation["pending_auth"],
            "pending_auth_dni": conversation["pending_auth_dni"],
            "pending_auth_phone": conversation["pending_auth_phone"],
            "authenticated_customer_id": conversation["authenticated_customer_id"],
            "last_order_id": conversation["last_order_id"],
            "last_order_list": list(conversation["last_order_list"]),
            "last_order_query_type": conversation["last_order_query_type"],
            "recent_turns": list(conversation["recent_turns"]),
        }


def update_session_context(
    last_intent=None,
    last_subintent=None,
    last_domain=None,
    last_topic=None,
    last_internal_topic=None,
    last_entities=None,
    last_result_type=None,
    last_result_summary=None,
    active_domain=None,
    active_category=None,
    active_subtype=None,
    active_brand=None,
    active_product_reference=None,
    active_result_scope=None,
    last_shown_products=None,
    reference_anchor=None,
    pending_auth=None,
    pending_auth_dni=None,
    pending_auth_phone=None,
    authenticated_customer_id=None,
    last_order_id=None,
    last_order_list=None,
    last_order_query_type=None,
    user_message=None,
    agent_message=None,
):
    with _LOCK:
        conversation = _STATE["conversation"]
        if last_intent is not None:
            conversation["last_intent"] = last_intent
        if last_subintent is not None:
            conversation["last_subintent"] = last_subintent
        if last_domain is not None:
            conversation["last_domain"] = last_domain
        if last_topic is not None:
            conversation["last_topic"] = last_topic
        if last_internal_topic is not None:
            conversation["last_internal_topic"] = last_internal_topic
        if last_entities is not None:
            conversation["last_entities"] = dict(last_entities)
        if last_result_type is not None:
            conversation["last_result_type"] = str(last_result_type or "") or None
        if last_result_summary is not None:
            conversation["last_result_summary"] = str(last_result_summary or "") or None
        if active_domain is not None:
            conversation["active_domain"] = str(active_domain or "") or None
        if active_category is not None:
            conversation["active_category"] = str(active_category or "") or None
        if active_subtype is not None:
            conversation["active_subtype"] = str(active_subtype or "") or None
        if active_brand is not None:
            conversation["active_brand"] = str(active_brand or "") or None
        if active_product_reference is not None:
            conversation["active_product_reference"] = dict(active_product_reference) if active_product_reference else None
        if active_result_scope is not None:
            conversation["active_result_scope"] = str(active_result_scope or "") or None
        if last_shown_products is not None:
            conversation["last_shown_products"] = list(last_shown_products)
        if reference_anchor is not None:
            conversation["reference_anchor"] = dict(reference_anchor) if reference_anchor else None
        if pending_auth is not None:
            conversation["pending_auth"] = bool(pending_auth)
        if pending_auth_dni is not None:
            conversation["pending_auth_dni"] = str(pending_auth_dni or "")
        if pending_auth_phone is not None:
            conversation["pending_auth_phone"] = str(pending_auth_phone or "")
        if authenticated_customer_id is not None:
            conversation["authenticated_customer_id"] = str(authenticated_customer_id or "") or None
        if last_order_id is not None:
            conversation["last_order_id"] = str(last_order_id or "") or None
        if last_order_list is not None:
            conversation["last_order_list"] = list(last_order_list)
        if last_order_query_type is not None:
            conversation["last_order_query_type"] = str(last_order_query_type or "") or None
        if user_message is not None or agent_message is not None:
            conversation["recent_turns"].append(
                {
                    "user": str(user_message or ""),
                    "assistant": str(agent_message or ""),
                }
            )
            conversation["recent_turns"] = conversation["recent_turns"][-3:]


def get_tool_traces():
    return get_tool_trace()
