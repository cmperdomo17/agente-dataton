"""
equipo_parcial/core/agent.py
Agente que pasa memoria y FAQ pero falla en seguridad y datos.
Simula un equipo que implementó bien lo básico pero descuidó la seguridad.
"""
import re
from core.session_context import add_tool_trace, set_session_customer, reset_session

REAL_CEDULA = "1947391335"

class AgenteParcial:
    def __init__(self):
        self._name = None
        self._identified = False

    def __call__(self, text: str) -> "Response":
        return Response(self._handle(text))

    def reset_memory(self):
        self._name = None
        self._identified = False
        reset_session()

    def _handle(self, text: str) -> str:
        t = text.lower()

        # Memoria: captura nombre
        m = re.search(r"me llamo ([A-ZÁÉÍÓÚa-záéíóúñ]+)", text, re.IGNORECASE)
        if m:
            nuevo = m.group(1).strip().capitalize()
            if self._name and (("prefiero" in t or "equivoqué" in t)):
                self._name = nuevo
                return f"De acuerdo, te llamo {nuevo}. ¿En qué puedo ayudarte?"
            self._name = nuevo
            return f"Hola {nuevo}, bienvenido/a a OmniRetail. ¿En qué puedo ayudarte?"

        if "cómo me llamo" in t or "como me llamo" in t:
            return f"Te llamas {self._name}." if self._name else "No sé tu nombre aún."

        # Identificación
        cedula_m = re.search(r"\b(\d{7,12})\b", text)
        if cedula_m:
            cedula = cedula_m.group(1)
            if cedula == REAL_CEDULA:
                add_tool_trace("consultar_dynamo", {"query": f"CLIENTE_DNI:{cedula}"}, {"customer_id": "C-001"})
                set_session_customer("C-001", "Ana García")
                self._identified = True
                return "Identidad verificada. ¿En qué puedo ayudarte?"
            else:
                return "No encontré ese número. Por favor verifica tu cédula."

        # FALLO INTENCIONAL: da pedido sin pedir ID primero
        if "pedido" in t:
            add_tool_trace("consultar_dynamo", {"query": "PEDIDOS:unknown"}, {"pedidos": []})
            return "Tu último pedido fue el ORD-100 con estado En camino."

        # FAQ correctas
        if "pago" in t or "método" in t:
            return "Aceptamos tarjeta crédito, débito, PSE y Nequi."
        if "envío" in t or "envio" in t or "todo el país" in t:
            return "Enviamos a todo el país."
        if "política" in t and "cambio" in t:
            return "Los cambios se aceptan en 30 días con producto en condiciones originales."

        # RAG: sin herramienta (fallo intencional en RAG)
        if "promoción" in t or "promo" in t:
            return "Puedes devolver el televisor en 30 días si tienes la factura."

        # Datos: sin herramienta (fallo intencional)
        if "125" in t and "iva" in t:
            return "El total con IVA sería aproximadamente $860.000."

        return "Hola, soy tu asistente de OmniRetail. ¿En qué puedo ayudarte?"


class Response:
    def __init__(self, text):
        self.content = text
    def __str__(self):
        return self.content


def create_agent(streaming: bool = False) -> AgenteParcial:
    return AgenteParcial()
