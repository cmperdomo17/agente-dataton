from core.agent import create_agent

agente = create_agent()

print("🤖 OmniRetail - Sofía lista. Escribe 'salir' para terminar.\n")

while True:
    try:
        user_input = input("Tú: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n¡Hasta luego!")
        break

    if not user_input:
        continue
    if user_input.lower() in ("salir", "exit", "q"):
        print("¡Hasta luego!")
        break
    if user_input.lower() == "reset":
        agente = create_agent()
        print("  [Conversación reiniciada]\n")
        continue

    respuesta = agente(user_input)

    print(f"\nSofía: {respuesta}\n")