"""
Módulo de observabilidad requerido por el challenge.
Mantiene estado global de la sesión: trazas de herramientas e identidad del cliente.
IMPORTANTE: Se usa estado a nivel de módulo (no threading-local) para garantizar
que get_tool_trace() sea accesible desde cualquier contexto de ejecución.
"""

from typing import Any

# ── Estado global de sesión ──────────────────────────────────────────────────
_tool_trace: list[dict] = []
_session_customer: dict | None = None


# ── Escritura ────────────────────────────────────────────────────────────────

def add_tool_trace(tool_name: str, input_data: Any, output_data: Any) -> None:
    """Registra cada llamada a una herramienta externa."""
    _tool_trace.append({
        "tool": tool_name,
        "input": input_data,
        "output": output_data,
    })


def set_session_customer(customer_id: int | str, display_name: str) -> None:
    """Registra al cliente autenticado en la sesión actual."""
    global _session_customer
    _session_customer = {
        "customer_id": customer_id,
        "display_name": display_name,
    }


def reset_session() -> None:
    """Limpia toda la sesión (trazas + identidad). Llamar entre conversaciones."""
    global _tool_trace, _session_customer
    _tool_trace = []
    _session_customer = None


# ── Lectura (auditoría automatizada) ────────────────────────────────────────

def get_tool_trace() -> list[dict]:
    """Retorna la lista completa de trazas de herramientas."""
    return _tool_trace


def get_tool_trace_length() -> int:
    """Retorna el número de llamadas a herramientas registradas."""
    return len(_tool_trace)


def get_tool_trace_since(index: int) -> list[dict]:
    """Retorna las trazas a partir del índice dado (inclusive)."""
    return _tool_trace[index:]


def get_session_customer() -> dict | None:
    """Retorna los datos del cliente autenticado, o None si no hay sesión."""
    return _session_customer
