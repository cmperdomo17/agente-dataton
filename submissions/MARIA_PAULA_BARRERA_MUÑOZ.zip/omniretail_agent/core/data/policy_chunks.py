"""
Divide los documentos Markdown de política por encabezados (##)
y selecciona los chunks más relevantes para una consulta dada.
El agente NUNCA inyecta el archivo completo — solo las secciones relevantes.
"""

import os
import re
from typing import List, Tuple

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_POLICY_DIR = os.path.join(_ROOT, "policies")

_FILES = {
    "devoluciones": "Política de devoluciones.md",
    "garantia":     "Política de garantía.md",
    "envios":       "Políticas de envío.md",
}

# ── Construcción del índice de chunks ───────────────────────────────────────

def _parse_chunks(text: str, source: str) -> List[dict]:
    """Divide un Markdown en chunks por encabezados ## o ###."""
    chunks = []
    current_title = source
    current_lines: list[str] = []

    for line in text.splitlines():
        if re.match(r"^#{1,3} ", line):
            if current_lines:
                chunks.append({
                    "source": source,
                    "title": current_title,
                    "content": "\n".join(current_lines).strip(),
                })
            current_title = re.sub(r"^#{1,3} \**", "", line).strip(" *")
            current_lines = []
        else:
            current_lines.append(line)

    if current_lines:
        chunks.append({
            "source": source,
            "title": current_title,
            "content": "\n".join(current_lines).strip(),
        })

    return [c for c in chunks if len(c["content"]) > 30]


def _build_index() -> List[dict]:
    all_chunks = []
    for key, filename in _FILES.items():
        path = os.path.join(_POLICY_DIR, filename)
        try:
            with open(path, encoding="utf-8") as f:
                text = f.read()
            all_chunks.extend(_parse_chunks(text, key))
        except FileNotFoundError:
            pass
    return all_chunks


_INDEX: List[dict] = _build_index()


# ── Búsqueda por relevancia (keyword matching simple y efectivo) ─────────────

_STOPWORDS = {
    "el", "la", "los", "las", "de", "del", "en", "un", "una", "es",
    "que", "por", "con", "para", "mi", "me", "se", "si", "a", "y",
    "o", "al", "lo", "le", "su", "sus", "hay", "como", "qué", "cuál",
    "tengo", "quiero", "necesito", "puedo", "puede", "cuándo", "cómo",
}

_TOPIC_KEYWORDS = {
    "devoluciones": ["devoluci", "cambio", "reembolso", "devolver", "cambiar",
                     "reembol", "plazo", "venta final", "elegible", "cancelar"],
    "garantia":     ["garantía", "garantia", "falla", "defecto", "roto", "daño",
                     "reparaci", "técnico", "cobertura", "vigencia"],
    "envios":       ["envío", "envio", "entrega", "despacho", "transportadora",
                     "tracking", "guía", "demora", "llegó", "llega", "días",
                     "dirección", "modificar"],
}


def search_policies(query: str, top_k: int = 3) -> List[dict]:
    """
    Retorna hasta top_k chunks ordenados por relevancia para la consulta.
    Algoritmo: peso por palabras clave en título (x3) + contenido (x1).
    """
    query_lower = query.lower()
    query_words = [w for w in re.findall(r"\w+", query_lower) if w not in _STOPWORDS]

    # Detectar qué documentos son más relevantes según el tema
    topic_boost: dict[str, float] = {k: 0.0 for k in _FILES}
    for topic, keywords in _TOPIC_KEYWORDS.items():
        for kw in keywords:
            if kw in query_lower:
                topic_boost[topic] += 2.0

    scored: List[Tuple[float, dict]] = []
    for chunk in _INDEX:
        score = topic_boost.get(chunk["source"], 0.0)
        title_lower = chunk["title"].lower()
        content_lower = chunk["content"].lower()

        for word in query_words:
            score += title_lower.count(word) * 3
            score += content_lower.count(word) * 1

        if score > 0:
            scored.append((score, chunk))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for _, c in scored[:top_k]]


def format_chunks(chunks: List[dict]) -> str:
    """Formatea los chunks seleccionados para inyectar en el prompt."""
    if not chunks:
        return "No se encontró información relevante en las políticas."
    parts = []
    for c in chunks:
        parts.append(f"### {c['title']} (fuente: política de {c['source']})\n{c['content']}")
    return "\n\n---\n\n".join(parts)
