"""
Carga todos los CSVs en memoria al iniciar el agente.
Se accede como singleton: from core.data.loader import DB
"""

import os
import pandas as pd

# Raíz del proyecto = carpeta que contiene a 'core/'
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_BASE = os.path.join(_ROOT, "data")


def _load(filename: str) -> pd.DataFrame:
    path = os.path.join(_BASE, filename)
    return pd.read_csv(path, dtype=str)


class _Database:
    def __init__(self):
        self.customers        = _load("customers.csv")
        self.orders           = _load("orders.csv")
        self.order_items      = _load("order_items.csv")
        self.products         = _load("products.csv")
        self.shipments        = _load("shipments.csv")
        self.tracking         = _load("tracking.csv")
        self.stock            = _load("stock.csv")
        self.promotions       = _load("promotions.csv")
        self.categories       = _load("categories.csv")
        self.brands           = _load("brands.csv")
        self.addresses        = _load("addresses.csv")
        self.customer_emails  = _load("customer_emails.csv")
        self.cards            = _load("cards.csv")


# Singleton — se instancia una sola vez al importar
DB = _Database()
