"""
Consulta pedidos, ítems, montos e historial de un cliente autenticado.
NUNCA se llama sin sesión activa — el agente debe verificar identidad primero.
"""

from strands import tool
from core.data.loader import DB
from core import session_context


def _cliente_autenticado() -> tuple[bool, str]:
    cliente = session_context.get_session_customer()
    if not cliente:
        return False, "necesita_autenticacion"
    return True, cliente["customer_id"]


@tool
def consultar_pedidos(order_id: str = "") -> str:
    """
    Consulta el estado y detalles de los pedidos de un cliente autenticado.
    Si se provee order_id, retorna ese pedido específico.
    Si no, retorna los últimos 5 pedidos del cliente.

    Requiere que el cliente esté autenticado previamente con verificar_identidad.

    Args:
        order_id: ID del pedido específico a consultar (opcional).

    Returns:
        Resumen de pedidos en texto natural.
    """
    ok, customer_id = _cliente_autenticado()
    if not ok:
        return "ACCIÓN_REQUERIDA: Debes verificar la identidad del cliente antes de consultar pedidos."

    orders_df = DB.orders

    if order_id:
        df = orders_df[
            (orders_df["order_id"] == str(order_id)) &
            (orders_df["customer_id"] == str(customer_id))
        ]
        if df.empty:
            resultado = f"No encontré el pedido #{order_id} para este cliente."
            session_context.add_tool_trace("consultar_pedidos", {"order_id": order_id}, resultado)
            return resultado
    else:
        df = orders_df[orders_df["customer_id"] == str(customer_id)]
        df = df.sort_values("order_date", ascending=False).head(5)

    if df.empty:
        resultado = "Este cliente no tiene pedidos registrados."
        session_context.add_tool_trace("consultar_pedidos", {}, resultado)
        return resultado

    resultados = []
    for _, row in df.iterrows():
        estado_map = {
            "pending":             "Pendiente",
            "payment_confirmed":   "Pago confirmado",
            "preparing":           "En preparación",
            "shipped":             "Despachado",
            "delivered":           "Entregado",
            "cancelled":           "Cancelado",
            "returned":            "Devuelto",
        }
        estado = estado_map.get(row.get("status", ""), row.get("status", ""))
        total = f"${float(row['total_amount']):,.0f}" if row.get("total_amount") else "N/D"
        fecha = str(row.get("order_date", ""))[:10]
        metodo = row.get("payment_method", "")
        envio = "Domicilio" if row.get("delivery_method") == "home_delivery" else "Punto de retiro"

        linea = (
            f"Pedido #{row['order_id']} | {fecha} | Estado: {estado} | "
            f"Total: {total} | Pago: {metodo} | Entrega: {envio}"
        )
        resultados.append(linea)

    salida = "\n".join(resultados)
    session_context.add_tool_trace("consultar_pedidos", {"order_id": order_id, "customer_id": customer_id}, salida)
    return salida


@tool
def consultar_monto_pedido(order_id: str) -> str:
    """
    Retorna el desglose financiero de un pedido: subtotal, IVA y total.
    Requiere autenticación previa.

    Args:
        order_id: ID del pedido a consultar.

    Returns:
        Desglose de montos del pedido.
    """
    ok, customer_id = _cliente_autenticado()
    if not ok:
        return "ACCIÓN_REQUERIDA: Debes verificar la identidad del cliente antes de mostrar montos."

    df = DB.orders[
        (DB.orders["order_id"] == str(order_id)) &
        (DB.orders["customer_id"] == str(customer_id))
    ]

    if df.empty:
        resultado = f"No encontré el pedido #{order_id} asociado a tu cuenta."
        session_context.add_tool_trace("consultar_monto_pedido", {"order_id": order_id}, resultado)
        return resultado

    row = df.iloc[0]
    subtotal = float(row.get("subtotal", 0))
    iva = float(row.get("tax", 0))
    envio = float(row.get("shipping_cost", 0))
    total = float(row.get("total_amount", 0))

    salida = (
        f"Pedido #{order_id}:\n"
        f"  Subtotal:      ${subtotal:,.2f}\n"
        f"  IVA (19%):     ${iva:,.2f}\n"
        f"  Costo de envío: ${envio:,.2f}\n"
        f"  Total:         ${total:,.2f}"
    )
    session_context.add_tool_trace("consultar_monto_pedido", {"order_id": order_id}, salida)
    return salida


@tool
def consultar_items_pedido(order_id: str) -> str:
    """
    Lista los productos incluidos en un pedido con su estado,
    fecha de vencimiento de garantía y plazo de devolución.
    Requiere autenticación previa.

    Args:
        order_id: ID del pedido a consultar.

    Returns:
        Lista de ítems del pedido.
    """
    ok, customer_id = _cliente_autenticado()
    if not ok:
        return "ACCIÓN_REQUERIDA: Debes verificar la identidad del cliente antes de consultar ítems."

    # Verificar que el pedido pertenece al cliente
    orden = DB.orders[
        (DB.orders["order_id"] == str(order_id)) &
        (DB.orders["customer_id"] == str(customer_id))
    ]
    if orden.empty:
        resultado = f"No encontré el pedido #{order_id} en tu cuenta."
        session_context.add_tool_trace("consultar_items_pedido", {"order_id": order_id}, resultado)
        return resultado

    items = DB.order_items[DB.order_items["order_id"] == str(order_id)]
    if items.empty:
        resultado = "Este pedido no tiene ítems registrados."
        session_context.add_tool_trace("consultar_items_pedido", {"order_id": order_id}, resultado)
        return resultado

    productos = DB.products.set_index("product_id")
    lineas = []
    for _, item in items.iterrows():
        pid = item.get("product_id", "")
        nombre = productos.loc[pid, "name"] if pid in productos.index else f"Producto {pid}"
        qty = item.get("qty", "1")
        precio = float(item.get("unit_price", 0))
        estado = item.get("item_status", "")
        garantia = str(item.get("warranty_expires_at", ""))[:10] or "N/D"
        devolucion = str(item.get("return_deadline", ""))[:10] or "Sin devolución"

        lineas.append(
            f"• {nombre} x{qty} — ${precio:,.0f} c/u | "
            f"Estado: {estado} | Garantía hasta: {garantia} | Devolución hasta: {devolucion}"
        )

    salida = f"Ítems del pedido #{order_id}:\n" + "\n".join(lineas)
    session_context.add_tool_trace("consultar_items_pedido", {"order_id": order_id}, salida)
    return salida
