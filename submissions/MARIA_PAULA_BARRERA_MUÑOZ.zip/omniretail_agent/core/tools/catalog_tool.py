"""
Consulta de catálogo, precios y stock. NO requiere autenticación.
"""

from strands import tool
from core.data.loader import DB
from core import session_context


@tool
def buscar_productos(nombre: str = "", categoria: str = "", marca: str = "") -> str:
    """
    Busca productos en el catálogo. Úsala SIEMPRE que el cliente pregunte por
    productos, precios, neveras, televisores, celulares, ropa, o cualquier artículo.
    No requiere autenticación. Puedes pasar nombre, categoría o marca — con uno basta.

    Categorías disponibles: Electrónica, Electrodomésticos, Hogar y Muebles,
    Ropa y Calzado, Deportes y Fitness, Belleza y Cuidado Personal,
    Libros y Papelería, Juguetes y Bebés.

    Args:
        nombre: Nombre o parte del nombre (ej: "nevera", "samsung galaxy", "tenis", "celular").
        categoria: Categoría del producto (ej: "Electrodomésticos", "Electrónica").
        marca: Marca del producto (ej: "Samsung", "Nike", "LG").

    Returns:
        Lista de productos con precio, stock y disponibilidad.
    """
    df = DB.products[DB.products["active"].str.lower() == "true"].copy()

    if nombre:
        query = nombre.lower().strip()

        # 🔹 1. búsqueda directa
        df_nombre = df[df["name"].str.lower().str.contains(query, na=False)]

        # 🔹 2. fallback por categoría
        if df_nombre.empty:
            CATEGORIA_FALLBACK = {
                "celular": "electrónica",
                "celulares": "electrónica",
                "telefono": "electrónica",
                "telefonos": "electrónica",
                "movil": "electrónica",
                "moviles": "electrónica",
                "smartphone": "electrónica",

                "televisor": "electrónica",
                "tv": "electrónica",
                "laptop": "electrónica",
                "computador": "electrónica",

                "nevera": "electrodomésticos",
                "lavadora": "electrodomésticos",
                "microondas": "electrodomésticos",
                "estufa": "electrodomésticos",

                "sofa": "hogar y muebles",
                "mesa": "hogar y muebles",
                "silla": "hogar y muebles",
                "colchon": "hogar y muebles",

                "tenis": "ropa y calzado",
                "zapatos": "ropa y calzado",
                "camisa": "ropa y calzado",
                "pantalon": "ropa y calzado",

                "mancuerna": "deportes y fitness",
                "bicicleta": "deportes y fitness",
                "balon": "deportes y fitness",

                "secador": "belleza y cuidado personal",
                "plancha": "belleza y cuidado personal",
                "afeitadora": "belleza y cuidado personal",

                "cuaderno": "libros y papelería",
                "libro": "libros y papelería",
                "lapiz": "libros y papelería",

                "juguete": "juguetes y bebés",
                "muñeca": "juguetes y bebés",
                "bebe": "juguetes y bebés",
            }

            if query in CATEGORIA_FALLBACK:
                categoria_busqueda = CATEGORIA_FALLBACK[query]

                cats = DB.categories
                cat_match = cats[cats["name"].str.lower().str.contains(categoria_busqueda)]

                if not cat_match.empty:
                    cat_ids = cat_match["category_id"].tolist()
                    df = df[df["category_id"].isin(cat_ids)]
                else:
                    df = df_nombre
            else:
                df = df_nombre

        else:
            df = df_nombre

    if categoria:
        cats = DB.categories
        cat_match = cats[cats["name"].str.lower().str.contains(categoria.lower(), na=False)]
        if not cat_match.empty:
            cat_ids = cat_match["category_id"].tolist()
            df = df[df["category_id"].isin(cat_ids)]

    if marca:
        brands = DB.brands
        brand_match = brands[brands["name"].str.lower().str.contains(marca.lower(), na=False)]
        if not brand_match.empty:
            brand_ids = brand_match["brand_id"].tolist()
            df = df[df["brand_id"].isin(brand_ids)]

    if df.empty:
        resultado = f"No encontré coincidencias exactas con '{nombre}', pero puedo ayudarte a buscar por marca o categoría. ¿Qué tienes en mente?"
        session_context.add_tool_trace("buscar_productos", {"nombre": nombre, "categoria": categoria, "marca": marca}, resultado)
        return resultado

    df = df.head(8)
    cats_idx = DB.categories.set_index("category_id")
    brands_idx = DB.brands.set_index("brand_id")
    stock_idx = DB.stock.set_index("product_id")

    lineas = []
    for _, row in df.iterrows():
        precio = f"${float(row['price']):,.0f}" if row.get("price") else "N/D"
        env_gratis = "✅ Envío gratis" if str(row.get("free_shipping", "")).lower() == "true" else ""
        cat_nombre = cats_idx.loc[row["category_id"], "name"] if row["category_id"] in cats_idx.index else ""
        brand_nombre = brands_idx.loc[row["brand_id"], "name"] if row["brand_id"] in brands_idx.index else ""

        # Stock disponible
        disponible = "N/D"
        pid = row["product_id"]
        if pid in stock_idx.index:
            sq = int(stock_idx.loc[pid, "stock_qty"] or 0)
            rq = int(stock_idx.loc[pid, "reserved_qty"] or 0)
            disp = sq - rq
            disponible = f"{disp} unidades" if disp > 0 else "Sin stock"

        final_sale = str(row.get("is_final_sale", "")).lower() == "true"
        sale_txt = " | ⚠️ Venta Final (sin devolución)" if final_sale else ""

        lineas.append(
            f"• [{row['product_id']}] {row['name']} — {precio} | {cat_nombre} | {brand_nombre} | "
            f"Stock: {disponible} {env_gratis}{sale_txt}"
        )

    salida = f"Productos encontrados ({len(df)}):\n" + "\n".join(lineas)
    session_context.add_tool_trace("buscar_productos", {"nombre": nombre, "categoria": categoria, "marca": marca}, salida)
    return salida


@tool
def consultar_stock(product_id: str) -> str:
    """
    Consulta la disponibilidad en inventario de un producto específico.
    No requiere autenticación.

    Args:
        product_id: ID del producto (ej: 5001).

    Returns:
        Información de stock del producto.
    """
    stock = DB.stock[DB.stock["product_id"] == str(product_id)]
    producto = DB.products[DB.products["product_id"] == str(product_id)]

    if producto.empty:
        resultado = f"No encontré el producto con ID {product_id}."
        session_context.add_tool_trace("consultar_stock", {"product_id": product_id}, resultado)
        return resultado

    nombre = producto.iloc[0]["name"]

    if stock.empty:
        resultado = f"{nombre}: información de stock no disponible."
        session_context.add_tool_trace("consultar_stock", {"product_id": product_id}, resultado)
        return resultado

    s = stock.iloc[0]
    total = int(s.get("stock_qty", 0) or 0)
    reservado = int(s.get("reserved_qty", 0) or 0)
    disponible = total - reservado
    restock = str(s.get("restock_date", ""))[:10]

    if disponible > 0:
        salida = f"{nombre}: {disponible} unidades disponibles."
    elif restock and restock != "nan":
        salida = f"{nombre}: sin stock actualmente. Reabastecimiento estimado: {restock}."
    else:
        salida = f"{nombre}: sin stock disponible por el momento."

    session_context.add_tool_trace("consultar_stock", {"product_id": product_id}, salida)
    return salida
