"""
Consulta el estado de envío y el historial de tracking de un pedido.
Requiere autenticación previa del cliente.
"""

from strands import tool
from core.data.loader import DB
from core import session_context


def _cliente_autenticado() -> tuple[bool, str]:
    cliente = session_context.get_session_customer()
    if not cliente:
        return False, ""
    return True, cliente["customer_id"]


@tool
def consultar_envio(order_id: str) -> str:
    """
    Consulta el estado actual del envío de un pedido: transportadora,
    número de guía, fecha estimada de entrega y últimos eventos de tracking.
    Requiere autenticación previa.

    Args:
        order_id: ID del pedido a consultar.

    Returns:
        Información de envío y últimos eventos de tracking.
    """
    ok, customer_id = _cliente_autenticado()
    if not ok:
        return "ACCIÓN_REQUERIDA: Debes verificar la identidad del cliente antes de consultar el envío."

    # Validar que el pedido es del cliente
    orden = DB.orders[
        (DB.orders["order_id"] == str(order_id)) &
        (DB.orders["customer_id"] == str(customer_id))
    ]
    if orden.empty:
        resultado = f"No encontré el pedido #{order_id} en tu cuenta."
        session_context.add_tool_trace("consultar_envio", {"order_id": order_id}, resultado)
        return resultado

    row_orden = orden.iloc[0]
    estado_orden = row_orden.get("status", "")

    # Buscar envío
    shipment = DB.shipments[DB.shipments["order_id"] == str(order_id)]

    # Últimos 5 eventos de tracking
    tracking = DB.tracking[DB.tracking["order_id"] == str(order_id)]
    tracking = tracking.sort_values("timestamp", ascending=False).head(5)

    estado_map = {
        "pending":           "Pendiente de pago",
        "payment_confirmed": "Pago confirmado, en preparación",
        "preparing":         "En preparación",
        "shipped":           "Despachado",
        "delivered":         "Entregado",
        "cancelled":         "Cancelado",
        "returned":          "Devuelto",
    }
    estado_legible = estado_map.get(estado_orden, estado_orden)

    partes = [f"📦 Pedido #{order_id} — Estado: {estado_legible}"]

    if not shipment.empty:
        s = shipment.iloc[0]
        transportadora = s.get("carrier", "N/D")
        guia = s.get("tracking_number", "N/D")
        url = s.get("tracking_url", "")
        entrega_estimada = str(s.get("estimated_delivery_date", ""))[:10] or "N/D"
        entrega_real = str(s.get("actual_delivery_date", ""))[:10]
        intentos = s.get("delivery_attempts", "0")

        partes.append(f"🚚 Transportadora: {transportadora}")
        partes.append(f"🔢 Número de guía: {guia}")
        partes.append(f"📅 Entrega estimada: {entrega_estimada}")
        if entrega_real:
            partes.append(f"✅ Entregado el: {entrega_real}")
        if url:
            partes.append(f"🔗 Seguimiento: {url}")
        if int(intentos) > 1:
            partes.append(f"⚠️ Intentos de entrega: {intentos}")

    if not tracking.empty:
        partes.append("\nÚltimos eventos:")
        for _, ev in tracking.iterrows():
            ts = str(ev.get("timestamp", ""))[:16]
            status = ev.get("status", "")
            loc = ev.get("location", "")
            loc_txt = f" — {loc}" if loc and str(loc) != "nan" else ""
            partes.append(f"  • {ts} | {status}{loc_txt}")

    salida = "\n".join(partes)
    session_context.add_tool_trace("consultar_envio", {"order_id": order_id}, salida)
    return salida
