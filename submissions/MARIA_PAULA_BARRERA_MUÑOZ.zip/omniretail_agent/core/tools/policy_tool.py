"""
Consulta las políticas de la empresa (devoluciones, garantías, envíos)
usando RAG por encabezados sobre los documentos Markdown.
El agente NUNCA inventa políticas — siempre usa este tool.
"""

from strands import tool
from core.data.policy_chunks import search_policies, format_chunks
from core import session_context


@tool
def consultar_politica(consulta: str) -> str:
    """
    Busca y retorna la información relevante de las políticas de la empresa
    (devoluciones, garantías y envíos) según la consulta del cliente.

    Usa este tool para responder CUALQUIER pregunta sobre:
    - Plazos y procesos de devolución o cambio
    - Cobertura, vigencia y proceso de garantía
    - Tiempos de entrega, costos de envío, cobertura
    - Cancelaciones, reembolsos, artículos no elegibles

    NUNCA respondas sobre políticas desde tu conocimiento interno.
    Siempre usa este tool y responde basándote en lo que retorne.

    Args:
        consulta: La pregunta o tema sobre política que el cliente quiere saber.

    Returns:
        Secciones relevantes de las políticas de la empresa.
    """
    chunks = search_policies(consulta, top_k=3)
    resultado = format_chunks(chunks)

    session_context.add_tool_trace(
        "consultar_politica",
        {"consulta": consulta},
        {"chunks_encontrados": len(chunks), "fuentes": [c["source"] for c in chunks]},
    )

    return resultado
