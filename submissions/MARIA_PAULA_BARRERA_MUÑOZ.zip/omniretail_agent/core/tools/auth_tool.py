"""
Verifica la identidad del cliente usando DNI o número de celular.
Registra la sesión en session_context cuando la verificación es exitosa.
"""

from strands import tool
from core.data.loader import DB
from core import session_context


@tool
def verificar_identidad(dni: str = "", celular: str = "") -> str:
    """
    Verifica la identidad de un cliente usando su número de cédula (DNI)
    o su número de celular registrado.

    Usa este tool SIEMPRE antes de responder cualquier consulta sobre:
    - Estado de pedidos específicos
    - Historial de compras
    - Montos, subtotales o IVA de un pedido
    - Devoluciones o garantías de un pedido concreto

    Args:
        dni: Número de cédula o documento de identidad del cliente.
        celular: Número de celular registrado (con o sin espacios/código de país).

    Returns:
        Confirmación de identidad o mensaje de error.
    """
    df = DB.customers

    cliente = None

    if dni:
        dni_limpio = dni.strip().replace(" ", "")
        coincidencias = df[df["dni"].str.strip() == dni_limpio]
        if not coincidencias.empty:
            cliente = coincidencias.iloc[0]

    if cliente is None and celular:
        cel_limpio = celular.strip().replace(" ", "").replace("-", "")
        df_cel = df["phone"].str.replace(r"[\s\-]", "", regex=True)
        coincidencias = df[df_cel.str.endswith(cel_limpio[-7:])]
        if not coincidencias.empty:
            cliente = coincidencias.iloc[0]

    if cliente is None:
        resultado = "No encontré ningún cliente con esos datos. Por favor verifica tu cédula o celular."
        session_context.add_tool_trace(
            "verificar_identidad",
            {"dni": dni, "celular": celular},
            resultado,
        )
        return resultado

    # Verificar que la cuenta esté activa
    estado = cliente.get("account_status", "active")
    if estado == "suspended":
        resultado = "Tu cuenta está suspendida. Por favor contáctanos para más información."
        session_context.add_tool_trace(
            "verificar_identidad",
            {"dni": dni, "celular": celular},
            resultado,
        )
        return resultado

    customer_id = cliente["customer_id"]
    nombre = f"{cliente['name']} {cliente['last_name1']}".strip()
    es_premium = cliente.get("is_premium", "false").lower() == "true"

    session_context.set_session_customer(customer_id, nombre)
    session_context.add_tool_trace(
        "verificar_identidad",
        {"dni": dni, "celular": celular},
        {"customer_id": customer_id, "nombre": nombre, "autenticado": True},
    )

    premium_txt = " (cliente Premium ⭐)" if es_premium else ""
    return f"Identidad verificada. Bienvenido, {nombre}{premium_txt}. customer_id={customer_id}"