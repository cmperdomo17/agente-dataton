# OmniRetail Agent — Challenge Strata Analytics

## Descripción

OmniRetail Agent es un asistente conversacional orientado a retail que permite:

- Buscar productos y consultar stock  
- Consultar pedidos (requiere autenticación)  
- Revisar estado de envíos  
- Consultar políticas (devoluciones, garantía, envíos)  
- Validar identidad del cliente (cédula o celular)  

El agente está construido usando **strands** y modelos de **AWS Bedrock**.

---

## Estructura del proyecto

```
omniretail/
├── core/
│   ├── agent.py               ← Orquestador principal (create_agent)
│   ├── session_context.py     ← Manejo de estado de la conversación
│   ├── tools/
│   │   ├── auth_tool.py       ← Verificación de identidad
│   │   ├── orders_tool.py     ← Consulta de pedidos
│   │   ├── shipment_tool.py   ← Información de envíos
│   │   ├── catalog_tool.py    ← Búsqueda de productos y stock
│   │   └── policy_tool.py     ← Consulta de políticas
│   └── data/
│       ├── loader.py          ← Carga de datos CSV
│       └── policy_chunks.py   ← Búsqueda en documentos Markdown
│
├── data/                      ← Archivos CSV (clientes, pedidos, etc.)
├── policies/                  ← Políticas en formato Markdown
├── main.py                    ← Script de prueba por consola
├── requirements.txt
└── README.md
```

---

## Requisitos

- Python 3.10 o superior  
- pip  

---

## Instalación

### 1. Crear entorno virtual

**Windows:**

```
python -m venv .venv
.venv\Scripts\activate
```

**Linux / macOS:**

```
python3 -m venv .venv
source .venv/bin/activate
```

---

### 2. Instalar dependencias

```
pip install -r requirements.txt
```

---

## Dependencias utilizadas

El proyecto solo requiere:

- strands-agents  
- boto3  
- pandas  

---

## Configuración AWS

El agente utiliza AWS Bedrock, por lo que debes configurar credenciales.

### Linux / macOS

```
export AWS_ACCESS_KEY_ID=tu_access_key
export AWS_SECRET_ACCESS_KEY=tu_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

### Windows (PowerShell)

```
setx AWS_ACCESS_KEY_ID "tu_access_key"
setx AWS_SECRET_ACCESS_KEY "tu_secret_key"
setx AWS_DEFAULT_REGION "us-east-1"
```

## Terminal del editor (Windows - PowerShell)

```
$env:AWS_ACCESS_KEY_ID="..."
$env:AWS_SECRET_ACCESS_KEY="..."
$env:AWS_REGION="us-east-1"
```
### Alternativa

```
~/.aws/credentials
```

---

## Uso del agente

```
from core.agent import create_agent

agente = create_agent()

# Consulta general
respuesta = agente("¿Cuánto tarda un envío?")
print(respuesta)

# Consulta de pedido (requiere autenticación)
respuesta = agente("Quiero ver mi pedido")
print(respuesta)
```

---

## Modo prueba (main.py)

El archivo `main.py` permite probar el agente en consola.

```
python main.py
```

Ejemplos de preguntas:

- "¿Tienen celulares?"
- "Quiero ver mi pedido"
- "¿Cuál es la política de devoluciones?"
- "Mi cédula es 123456789"

Este modo es útil para validar el comportamiento del agente sin necesidad de integraciones adicionales.

---

## Cambiar modelo

En `core/agent.py` puedes modificar el modelo de Bedrock

---

## Consideraciones importantes

- No es necesario instalar librerías adicionales fuera de `requirements.txt`  
- No se incluye el entorno virtual (`.venv`) en el proyecto  
- El sistema depende de los archivos en `data/` y `policies/`  
- Las consultas de pedidos requieren autenticación previa  
- El agente puede requerir mejoras en manejo de sinónimos o lenguaje natural  

---

## Autor

María Paula Barrera Muñoz
