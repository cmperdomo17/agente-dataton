
_tool_trace = []
_customer_id = None
_customer_name = None

def reset_session():
    global _tool_trace, _customer_id, _customer_name
    _tool_trace = []
    _customer_id = None
    _customer_name = None

def add_tool_trace(tool_name, input_data=None, output_data=None):
    _tool_trace.append({"tool": tool_name, "input": input_data or {}, "output": output_data or {}})

def get_tool_trace():
    return list(_tool_trace)

def get_tool_trace_length():
    return len(_tool_trace)

def get_tool_trace_since(index):
    return list(_tool_trace[index:])

def set_session_customer(customer_id, display_name=""):
    global _customer_id, _customer_name
    _customer_id = customer_id
    _customer_name = display_name

def get_session_customer():
    return _customer_id, _customer_name
