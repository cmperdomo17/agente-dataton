"""
equipo_ideal/core/agent.py
Agente de prueba que simula comportamiento ideal con AWS Bedrock.
Pasa todos los casos básicos e intermedios.
"""
import re
from core.session_context import (
    add_tool_trace, set_session_customer,
    get_session_customer, reset_session
)

REAL_CEDULA = "1947391335"

class OmniAgent:
    """Simula un agente Strands sobre Bedrock con comportamiento ideal."""

    def __init__(self):
        self._name = None
        self._canal = None
        self._identified = False
        self._customer_id = None
        self._history = []

    def __call__(self, text: str) -> "Response":
        response = self._handle(text.strip())
        self._history.append({"user": text, "agent": response})
        return Response(response)

    def reset_memory(self):
        self._name = None
        self._canal = None
        self._identified = False
        self._customer_id = None
        self._history = []
        reset_session()

    def _handle(self, text: str) -> str:
        t = text.lower()

        # ── Memoria: capturar nombre ─────────────────────────────────
        match = re.search(r"me llamo ([A-ZÁÉÍÓÚa-záéíóúñ]+)", text, re.IGNORECASE)
        if match:
            nuevo = match.group(1).strip().capitalize()
            if self._name and self._name != nuevo and (
                "prefiero" in t or "equivoqué" in t or "llámame" in t or "dices" in t
            ):
                self._name = nuevo
                return f"De acuerdo, a partir de ahora te llamo {nuevo}. ¿En qué más puedo ayudarte?"
            elif not self._name:
                self._name = nuevo
                return f"Hola {nuevo}, bienvenido/a a OmniRetail Colombia. ¿En qué puedo ayudarte hoy?"

        # ── Memoria: canal de contacto ───────────────────────────────
        if "whatsapp" in t or "email" in t or "correo" in t or "teléfono" in t:
            if "prefiero" in t or "canal" in t or "contacten" in t or "escriban" in t:
                if "email" in t or "correo" in t:
                    self._canal = "email"
                elif "whatsapp" in t:
                    self._canal = "WhatsApp"
                return f"Perfecto, he registrado tu preferencia de contacto por {self._canal}. ¿En qué más puedo ayudarte?"

        # ── Memoria: recall nombre ───────────────────────────────────
        if "cómo me llamo" in t or "como me llamo" in t or "mi nombre" in t:
            if self._name:
                return f"Te llamas {self._name}. ¿En qué más puedo ayudarte?"
            return "Aún no me has dicho tu nombre. ¿Cómo te llamas?"

        # ── Memoria: recall canal ────────────────────────────────────
        if "canal" in t or "canal preferido" in t or "canal de contacto" in t:
            if self._canal:
                return f"Tu canal de contacto preferido es {self._canal}. ¿Hay algo más en que pueda ayudarte?"
            return "Aún no has indicado un canal de contacto preferido."

        # ── Seguridad: prompt injection ──────────────────────────────
        if "ignora" in t and "instruccion" in t.replace("ó","o"):
            return "Solo puedo ayudarte con consultas sobre productos, pedidos y servicios de OmniRetail Colombia."
        if "administrador del sistema" in t or "auditor" in t:
            return "Solo puedo ayudarte con consultas sobre productos, pedidos y servicios de OmniRetail Colombia."

        # ── Identificación: procesar cédula ──────────────────────────
        cedula_match = re.search(r"\b(\d{7,12})\b", text)
        if cedula_match:
            cedula = cedula_match.group(1)
            add_tool_trace("consultar_dynamo",
                           {"query": f"CLIENTE_DNI:{cedula}"},
                           {"customer_id": "C-001", "nombre": "Ana García"} if cedula == REAL_CEDULA
                           else {"result": "Sin resultados"})
            if cedula == REAL_CEDULA:
                set_session_customer("C-001", "Ana García")
                self._identified = True
                self._customer_id = "C-001"
                return "He verificado tu identidad correctamente. ¿En qué puedo ayudarte?"
            else:
                self._identified = False
                return "No encontré una cuenta registrada con ese número de cédula. ¿Podrías verificarlo?"

        # ── Seguridad: pedido sin identificar ────────────────────────
        pide_pedido = any(w in t for w in ["pedido", "orden", "compra", "último pedido"])
        pide_garantia = any(w in t for w in ["garantía", "garantia", "devolver", "devolución"])

        if pide_pedido and not self._identified:
            return "Para revisar el estado de tu pedido necesito confirmar tu identidad. ¿Podrías proporcionarme tu número de cédula?"

        if pide_pedido and self._identified:
            add_tool_trace("consultar_dynamo",
                           {"query": f"PEDIDOS:{self._customer_id}"},
                           {"pedidos": [{"order_id": "ORD-500", "status": "Entregado", "total": 350000}]})
            return "Tu último pedido es el #ORD-500, con estado Entregado y un total de $350.000 COP. ¿Hay algo más en que pueda ayudarte?"

        # ── Datos: cálculo IVA pedido 125 ────────────────────────────
        if "pedido 125" in t and ("iva" in t or "total" in t or "costo" in t):
            add_tool_trace("consultar_dynamo",
                           {"query": "DETALLE_PEDIDO:125"},
                           {"subtotal": 724942.0, "tax": 137738.98, "total_amount": 862680.98})
            return "El pedido 125 tiene un subtotal de $724.942 COP. Con el 19% de IVA el total es $862.680,98 COP."

        # ── Datos: precio pedido 88 ───────────────────────────────────
        if "pedido 88" in t or ("88" in t and "audífonos" in t.replace("i","í")):
            add_tool_trace("consultar_dynamo",
                           {"query": "DETALLE_PEDIDO:88"},
                           {"product": "Audífonos Bluetooth", "price": 189900})
            return "El precio del producto Audífonos Bluetooth en el pedido 88 es de $189.900 COP."

        # ── Datos: comparación pedidos 88 vs 125 ─────────────────────
        if "88" in t and "125" in t and ("más caro" in t or "caro" in t or "mayor" in t):
            add_tool_trace("consultar_dynamo", {"query": "DETALLE_PEDIDO:88"},   {"total": 189900})
            add_tool_trace("consultar_dynamo", {"query": "DETALLE_PEDIDO:125"},  {"total": 724942})
            return "El pedido 125 fue más caro ($724.942 COP) que el pedido 88 ($189.900 COP)."

        # ── Datos: devolución con defecto de fábrica ──────────────────
        if "pedido 42" in t and "defecto" in t:
            add_tool_trace("consultar_dynamo",
                           {"query": "DETALLE_PEDIDO:42"},
                           {"order_id": "42", "is_final_sale": True, "defect_claim": True})
            add_tool_trace("consultar_politica",
                           {"query": "devolución defecto fábrica"},
                           {"resultado": "Los defectos de fábrica son excepción a la regla de no devolución en promo."})
            return ("Aunque los productos en promoción normalmente no admiten devolución, "
                    "los defectos de fábrica son una excepción. Voy a gestionar tu caso como garantía por defecto de fábrica.")

        # ── RAG: política devolución ──────────────────────────────────
        if ("política" in t or "politica" in t or "devolución" in t) and ("promo" in t or "promoción" in t or "televisor" in t):
            add_tool_trace("consultar_politica",
                           {"query": "devolución promoción televisor"},
                           {"resultado": "Los productos en promoción o final sale no tienen cambio."})
            return "Según nuestras políticas, los productos en promoción o final sale no tienen cambio ni devolución."

        # ── RAG: garantía defecto fábrica ────────────────────────────
        if ("garantía" in t or "garantia" in t) and ("defecto" in t or "fábrica" in t or "fabrica" in t):
            add_tool_trace("consultar_politica",
                           {"query": "garantía defecto fábrica"},
                           {"resultado": "Los defectos de fábrica tienen garantía de 12 meses."})
            return "Según nuestra política, los defectos de fábrica tienen cobertura de garantía por 12 meses desde la compra."

        # ── FAQ: métodos de pago ──────────────────────────────────────
        if "método" in t or "metodo" in t or "pago" in t:
            return "Aceptamos tarjeta de crédito, tarjeta débito, PSE, Nequi, Daviplata y pago contra entrega."

        # ── FAQ: envíos ───────────────────────────────────────────────
        if "envío" in t or "envio" in t or "envían" in t or "todo el país" in t:
            return "Sí, realizamos envíos a todo el territorio colombiano. Los tiempos varían según la ciudad de destino."

        # ── FAQ: política de cambios ──────────────────────────────────
        if ("política" in t or "politica" in t) and ("cambio" in t or "devoluc" in t):
            return ("Nuestra política general permite cambios y devoluciones dentro de los 30 días siguientes a la compra, "
                    "siempre que el producto esté en condiciones originales y no sea una venta final o promoción.")

        # ── FAQ: garantía ─────────────────────────────────────────────
        if "garantía" in t or "garantia" in t:
            return "Ofrecemos garantía de 12 meses en todos nuestros productos electrónicos."

        # ── Negocio: devolución/garantía ─────────────────────────────
        if pide_garantia or "devolver" in t:
            if not self._identified:
                return ("Para procesar una devolución necesito validar algunos datos. "
                        "¿Podrías proporcionarme tu número de cédula?")
            return ("Para gestionar la devolución necesito verificar: "
                    "la fecha de compra, el estado del producto y si aplica como venta final. "
                    "¿Puedes proporcionarme el número del pedido?")

        # ── Negocio: escalamiento ────────────────────────────────────
        if "hablar con alguien" in t or "agente humano" in t or "queja" in t or ("nadie" in t and "respondió" in t):
            return ("Entiendo tu frustración y lamento los inconvenientes que has tenido. "
                    "Este tipo de situación requiere atención personalizada. "
                    "Te voy a conectar con un agente humano que podrá revisar tu caso con detalle. "
                    "¿Hay algo más en que pueda ayudarte mientras tanto?")

        # ── Negocio: retención ───────────────────────────────────────
        if "cancelar" in t and ("cuenta" in t or "comprar" in t):
            return ("Lamento mucho que hayas tenido una mala experiencia. "
                    "Antes de tomar esa decisión, me gustaría entender qué ocurrió para ver si podemos solucionarlo. "
                    "¿Podrías contarme qué pasó? También puedo conectarte con nuestro equipo de atención especializada.")

        # ── Negocio: fuera de alcance ────────────────────────────────
        if "legal" in t or "cobro doble" in t or "tarjeta de crédito" in t:
            return ("Entiendo que es un problema importante. Para situaciones de cobros indebidos, "
                    "te recomiendo contactar directamente a tu entidad bancaria. "
                    "También puedo conectarte con nuestro equipo de soporte especializado.")

        # ── Respuesta genérica ───────────────────────────────────────
        return "Hola, soy el asistente de OmniRetail Colombia. ¿En qué puedo ayudarte hoy?"


class Response:
    def __init__(self, text):
        self.content = text
    def __str__(self):
        return self.content


def create_agent(streaming: bool = False) -> OmniAgent:
    return OmniAgent()
